#Practica. Actividad 2.
				UPV-EHU 2016/2017
                            
                            
                            
                Estructuras de Datos y Algoritmos
                          

              
              
                
                
                											Josu Alvarez
                                                            David Max

* * * *
##Indice

Mas informacion en la pagina web del proyecto: [GITHUB](http://txusyk.github.io/EDA16-17/): http://txusyk.github.io/EDA16-17/

[TOC]

* * *

##1. Introducción

**Siguiendo las indicaciones que nos dejaste en la evaluación de la primera actividad, hemos implementado una versión del algoritmo de ordenacion** (*QuickSort*) **mas simplificada y menos confusa**.

**Se han completado y probado todas las clases** que entregaste y los test, respectivamente. ** Hemos implementado la parte opcional del *OrderedCircularLinkedList* **(FilmList) y *UnorderedCircularLinkedList* (ActorList). Hemos decidido añadirlas a dichas clases dado que **si sustituiamos el HashMap< String, T > que tenemos para los catálogos de actores y peliculas el coste del programa se nos disparaba**. Por lo tanto, **desde la perspectiva de la eficiencia, hemos decidido que** dichas estructuras de datos **manejen menos volumen de información.**

**Dado un fichero de datos** que contiene actores y actrices de Internet Movie DataBase (IMDB), con una estructura efinida ('nombrePelicula' ---> 'nombreActor1' &&& 'nombreActor2'...) . **Se ha de implementar un programa que cargue el fichero de datos y extraiga del mismo los nombres de los actores y las peliculas que contiene**.

**El pilar del funcionamiento de nuestro programa son las búsquedas**. Dado que tanto para añadir, eliminar como para gestionar alguno de los datos previamente se hará una búsqueda para comprobar si realmente existe.

Dado que disponiamos de tiempo y que el proyecto nos ha parecido interesante, **hemos decidido implementar ciertas mejoras sobre el trabajo inicial**, siendo estas:

- ** El sistema dará la opción** al usuario para que decida como quiere ejecutar el programa, si por la **consola o bien mediante una GUI** que hemos construido con Swing.
- **Hay dos formas de cargar el archivo**, una **con todos los datos y** otra **con los datos normalizados** (se explica mejor en las proximas lineas).
- **Todo el proyecto** y todas sus versiones estan **siendo manejadas mediante GitHub**, se ha dispuesto una pagina web publica que contiene esta misma información y será actualizada con cada una de las proximas entregas.
- **Uso exclusivo de lenguaje 'Markdown' para proceder a documentar el codigo**. En nuestro esfuerzo por usar tecnologías libres y ser eficientes, hemos encontrado este lenguaje ideal (dada su total compatibilidad con las wikis y las webs de GitHub).
- **Uso del ingles** siempre que nos ha sido posible, para desarrollar el codigo de forma universal y que cualquier programador interesado lo pueda revisar, utilizar o mejorar desde el GitHub habilitado para ello.

**Hemos definido que el programa cumpla** las siguientes funciones:

1. ***Carga de datos desde fichero:* ** Se dará a elegir al usuario si quiere cargar la lista completa o solo querrá cargar los actores/peliculas que se encuentren bien escritos, es decir, que sean legibles tras haber sido tratados con un método que hemos establecido para normalizar nombres en base a caracteres desconocidos.
1. ***Búsqueda de un actor/película:* ** Devolvera el actor en caso de existir, en caso contrario dará un aviso por terminal/pop-up.
1. ***Inserción de un actor/película:* ** Indica si ha sido posible añadir el actor o si el mismo existía previamente.
1. ***Eliminación de un actor/película:* ** Indica si el actor existe y en ese caso, que ha sido borrado. En caso contrario informará de que no existe.
1. ***Obtener la lista de peliculas de un actor:* * ** Comprueba que el actor exista, y en caso positivo, muestra la lista de peliculas del mismo
1. ***Obtener la lista de actores de una pelicula (reparto):* **  Comprobamos que la pelicula existe previamente y en caso positivo, imprimimos por pantalla los actores que la componen. En caso de no existir, se informará de dicha situación al usuario.
1. ***Modificar el presupuesto de una pelicula:* ** Comprobamos que la pelicula introducida existe previamente y si es así, incrementamos el valor de recaudación en X (donde X es el valor introducido por el usuario). En caso de no existir la pelicula, se informará de dicha siatuación al usuario.
1. ***Obtener una lista de actores ordenada (nombre, apellido):* ** Obtenemos una lista de actores ordenados bajo el criterio: Nombre Apellido (separados unicamente por un espacio)
1. ***Exportar los datos a un fichero de texto:* ** Exportamos la lista ordenada de los actores, con sus respetivas peliculas a un fichero de texto `.txt`


* * *

## 2. Diagrama de clases

Este es el diseño final del programa, los diseños iniciales y la evolución de los mismos hasta llegar a esta se encuentran en nuestro GitHub.

![](/Users/Josu/Desktop/uml2.png)


* * *


## 3. Descripción de las estructuras de datos principales

Como comentábamos en la introducción del documento, **la parte más importante** del documento recae en los métodos que realizan **las búsquedas**. Dado que **son necesarios para trabajar la información, añadir y eliminarla**.

Tal como comentamos en la primera actividad, hicimos diferentes pruebas: búsqueda lineal y dicotómica. **Finalmente, vimos que podriamos tratar las búsquedas casi como un coste constante** si utilizabamos alguna estructura de datos de la familia **'Map'**. Por eso, replanteamos el diseño del programa e **hicimos que todas las estructuras de datos con las que trabajamos sean *HashMap < String, T >* ** donde 'T' es cualquier objeto que necesitemos almacenar (peliculas, actores...).

Teniendo en cuenta lo que se pedía para cumplimentar la segunda actividad. Hemos decidido implementar:
- ** *OrderedCircularLinkedList* ** en la clase ActorList (que contendrá el reparto de cada una de las peliculas).
- ** *UnorderedCircularLinkedList* ** en la clase FilmList (que contendrá la filmografia de cada actor)

Como **algoritmo de ordenación**, utilizábamos BubbleSort. Decidimos hacer modificaciones debido a que su coste era demasiado alto para lo que buscábamos (*O(n2)*). Hicimos distintas pruebas con MergeSort, aunque **finalmente optamos como algoritmo por el QuickSort reduciendo así el coste hasta O(n* log n)**.
Para realizar **la operación de ordenación**, previamente **volcamos las claves de nuestro HashMap** (que son los nombres de los actores) **en un Array[] de String y procedemos a ordenarlo**. **Tras esto, recibiremos una lista de claves ordenadas**, que en caso de querer mostrar unicamente los nombres de los actores cumple al 100% la función y en caso de querer mostrar mas información, lo recorreremos en orden y accederemos con cada clave a la información de nuestro catálogo (HashMap).
**Tal y como comentábamos en la introducción del documento, hemos simplificado nuestra versión del *QuickSort* ** y ahora es mucho mas sencilla.

## 4. Diseño e implementacion de los metodos principales

Este apartado lo dedicaremos a explicar el funcionamiento de los diferentes métodos principales de las clases a implementar en este laboratorio.

###4.1. CircularLinkedList:

####4.1.1 removeFirst()

#####4.1.1.1 Precondicion/Postcondicion
++Precondicion:++ Tendremos una lista de punteros
++Postcondicion:++ Tendremos la lista, sin el primer elemento.

#####4.1.1.2 Casos de prueba
* Lista null

#####4.1.1.3 Coste

El coste de esta operacion sera constante ***O(1)* **, ya que las operaciones que se harían son de coste constante, y las haremos sobre el primer el elemento al que accedemos.

#####4.1.1.4 Pseudo-algoritmo

		Nodo <T> primero = ultimo.sig;
        si(tamaño() == 1){
        	ultimo = null;
        }
        sino{
        	ultimo.sig = ultimo.sig.sig;
        }
        count--;
        return primero.info;

####4.1.1.5 Método final

```java
public T removeFirst() {
        // Elimina el primer elemento de la lista
        // Precondici�n: la lista tiene al menos un elemento
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE

        // Elimina el primer elemento de la lista
        // Precondici�n: la lista tiene al menos un elemento
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE

        Node<T> first = last.next;
        if (size() == 1) {
            last = null;
        } else {
            last.next = last.next.next;
        }
        count--;
        return first.data;
    }
```
#### 4.1.2 removeLast()
##### 4.1.2.1 Precondición/Postcondición
- ++Pre:++ Tendremos una lista de punteros.
- ++Post:++ Tendremos la lista sin el ultimo elemento.

##### 4.1.2.2 Casos de prueba
- Lista null

##### 4.1.2.3 Coste

El coste de este método será lineal ***O(n)* **, ya que tendremos que recorrer la lista entera antes de colocarnos delante del ultimo elemento para proceder a eliminarlo.

##### 4.1.2.4 Pseudo-algoritmo

```
	si(tamaño() == 1){
    	last = null;
    }
    sino{
    	Nodo <T> actual = ultimo.sig;
        mientras(actual.sig != ultimo){
        	actual = actual.sig;
        }
        ultimo = actual;
        ultimo.sig = ultimo.sig.sig;
    }
    cont --;
    return last.data;

```

##### 4.1.2.5 Metodo final (código)

```java
public T removeLast() {
        // Elimina el �ltimo elemento de la lista
        // Precondici�n: la lista tiene al menos un elemento
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE
        Node<T> pLast = last;
        if (size() == 1) {
            last = null;
        } else {
            Node<T> current = last.next;
            while (current.next != last) {
                current = current.next;
            }
            last = current;
            last.next = last.next.next;
        }
        count--;
        return pLast.data;
    }

```

* * *
####4.1.3 remove()


#####4.1.3.1 Precondicion/Postcondicion
- ++Precondicion:++ Tendremos un elemento de una lista.
- ++Postcondicion:++ Tendremos la lista sin el elemento.

#####4.1.3.2 Casos de prueba
* Lista null
* Elemento no existente en la lista.
* El elemento a añadir es nulo.

####4.1.3.3 Coste
Este algoritmo tendra un coste de ***O(n)* ** en el peor de los casos, ya que suponiendo que el ultimo elemento sea el que queremos eliminar, tendremos que recorrer la lista entera.
Pero en caso de que sea el primer elemento el que queremos eliminar, el coste del algoritmo sería constante ***O(1)* ** ya que nos valdria con acceder al primer elemento mediante el puntero 'first'.

####4.1.3.4 Pseudo-algoritmo
	public T remove(T elem) {
		Nodo <T> actual = primero;
    	int i = 0;
    	T numReturn;

    	si(this.vacio()){
    		return null;
    	}
    	sino{
    		mientras(!actual.sig.info.igual(elem)){
        		actual = actual.sig;
            	i++;
        	}
			si(i==cont){
        		System.out.println("El elemento no esta");
            	return null;
        	}
        	sino{
        		si(cont == 1){
            		numReturn = last.data;
                	last=null;
            	}
            	else{
            		numReturn = actual.next.data;

                	si(actual.sig == ultimo){
                		ultimo = actual;
                	}
                	actual.sig = actual.sig.sig;
            	}
            	cont--;
            	System.out.println("\n -> "+elem+" no ha sido eliminado);
            	return numReturn
        	}
        }



####4.1.3.5 Método final

```java
 public T remove(T elem) {
        Node<T> current = last;
        int i = 0;
        T returnNum;

        if (this.isEmpty()){ return null;} //if its empty we return null
        else{//if not null
            while(!current.next.data.equals(elem) && i!=size()){//goes out when finds the element or overpass the size
                current = current.next;
                i++;
            }
            if (i==count){//if the elemente isn't finded
                System.out.println("The element isn't finded");
                return null;
            }else{//we find it. we have to remove currents pointing node
                if (count == 1){//if we only have one element
                    returnNum = last.data;
                    last = null;
                }else{//if are more elements than 1
                    returnNum = current.next.data;

                    if (current.next == last) {
                        last = current;//if the element is the last we dont lose the pointer, we give it to the previous item
                    }
                    current.next = current.next.next;
                }
                count--;
                System.out.println("\n ->  "+elem+" it's been deleted");
                return returnNum;
            }
        }
    }

```

####4.1.5 find()

#####4.1.5.1 Precondicion/PostCondicion
- ++Precondición++: El programa recibe un elemento
- ++Postcondición++: Nos devolvera el numero si lo ha encontrado, y null si no existe.

#####4.1.5.2 Casos de prueba
* Lista vacía
* El elemento a añadir es nulo.

#####4.1.5.3 Coste
El coste de este algoritmo será en el peor de los casos ***O(n)* ** ya que tendremos que recorrer la lista hasta su ultimo elemento para eliminarlo.
Pero en el mejor de los casos el coste sería costante ***O(1)* **, ya que nos valdría el puntero first para acceder al primer elemento.

#####4.1.5.4 Pseudo-algoritmo

	public T find(T elem) {
        //Determina si la lista contiene un elemento concreto, y develve su referencia, null en caso de que no est�
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE
        Integer i = 0;
        T numReturn;
        Nodo<T> actual = ultimo;

        si(this.esVacio()){
        	return null;
        }
        sino{
        	mientras(!actual.data.igual(elem) && i!=tamaño()){
            	actual = actual.next;
                i++;
            }
            if(i==cont){
            	return null;
            }
            sino{
            	numReturn = actual.data;
				return numReturn;
            }
        }
	}



#####4.1.5.5 Método final

```java
public T find(T elem) {
        //Determina si la lista contiene un elemento concreto, y develve su referencia, null en caso de que no está
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE
        Integer i = 0;
        T returnNum;
        Node<T> current = last;

        if(this.isEmpty()){
            return null;
        }
        else{//si hay elementos, buscamos nuestro elemento
            while(!current.data.equals(elem) && i!=size()){//tiene que salir si recorre todos los elementos
                current = current.next;
                i++;
            }
            if(i==count){//no lo ha encontrado
                return null;
            }
            else{//lo a encontrado
                returnNum = current.data;
                return returnNum;
            }

        }
    }
```


###4.2 UnorderedCircularLinkedList

####4.2.1 addToFront()

#####4.2.1.1 Precondicion/Postcondicion
- ++Precondicion:++ El programa recibira un elemento.
- ++Postcondicion:++ El elemento esta añadido en la primera posición de la lista.

#####4.2.1.2 Casos de prueba
* La lista es nula.
* El elemento a añadir es nulo.

#####4.2.1.3 Coste
El coste de este algoritmo sera constante ***O(1)* ** ya que el elemento se añadira a la primera posición de la lista, posición a la cual accederemos directamente mediante el puntero 'first'.

#####4.2.1.4 Pseudo-algoritmo

	public void addToFront(T elem){
        Nodo<T> auxN = nuevo Nodo<T>(elem);
        si(esVacia()){
        	ultimo = auxN;
        }
        sino{
        	auxN.sig = ultimo.sig;
            ultimo.sig = auxN;
        }
        cont++;
	}

#####4.2.1.5 Método final

```java
public void addToFront(T elem){

        Node<T> newNode = new Node<T>(elem);
		if(isEmpty()){
			last = newNode;
            last.next = last;
		}
		else{
			newNode.next = last.next;
			last.next = newNode;
		}
		count++;
	}

```

####4.2.2 addToRear()

#####4.2.2.1 Precondición/Postcondición
- ++Precondición:++ El programa recibe un elemento.
- ++Postcondición:++ El programa habra añadido ese elemento al final de la lista.

#####4.2.3.2 Casos de prueba
* La lista es nula.
* El elemento a añadir es nulo.

#####4.2.3.3 Coste
El coste de este algoritmo será constante ** *O(1)* **, ya que gracias al puntero 'last' accederemos a la ultima posición directamente, y así podremos añadir en un solo paso el elemento al final de la lista.

#####4.2.3.3 Pseudo-algoritmo
	public void addToRear(T elem) {
    	Nodo <T> auxN = nuevo Nodo<T>(elem);
    	si(esVacia()){
        	ultimo = auxN;
            ultimo.sig = ultimo;
        }
        sino{
        	auxN.sig = ultimo.sig;
            ultimo.sig = auxN;
            ultimo = auxN;
        }
        cont++;
	}

####4.2.3 addAfter()

#####4.2.3.1 Precodición/Postcondición
- ++Precondición:++ Recibiremos 2 elementos, el primero será el que tendremos que añadir a la lista, y el segundo sera el objetivo detras del cual deberemos añadir el elemento.
- ++Postcondición:++ El primer elemento se habra colocado detras del segundo.

#####4.2.3.2 Casos de prueba
* Lista nula.
* Elemento a añadir nulo.
* Elemento objetivo nulo.

#####4.2.3.3 Coste
El coste de este algoritmo en el peor de los casos será ***O(n)* ** ya que tendremos que recorrer la lista elemento tras elemento hasta encontrar el objetivo. Pero en caso de que el objetivo sea el ultimo elemento, el coste sera constante ***O(1)* ** ya que empezaremos a recorrer la lista desde el último elemento.

#####4.2.3.4 Pseudo-algoritmo
	public void addAfter(T elem, T objetivo) {
        Nodo<T> auxN = nuevo Nodo<T>(elem);
        Nodo<T> actual = ultimo;

        mientras(!actual.info.igual(objetivo)){
        	actual = actual.sig;
        }
        auxN.sig = actual.sig;
        actual.sig = auxN;
        cont++;
	}

#####4.2.3.5 Método final
```java
public void addAfter(T elem, T target) {
        Node<T> newNode = new Node<T>(elem);
		Node<T> current = last;

		while(!current.data.equals(target)){
			current = current.next;
		}
		newNode.next = current.next;
		current.next = newNode;
		count++;
}

```

###4.3 OrderedCircularLikedList

####4.3.1 add()

#####4.3.1.1 Precondición/Postcondición
- ++Precondición:++ El programa recibirá un elemento a añadir.
- ++Postcondición:++ El programa habrá añadido el elemento ordenadamente.

#####4.3.1.2 Casos de prueba
* Lista nula.
* El elemento a añadir es nulo.

#####4.3.1.3 Coste
El coste de este algoritmo será ***O(n)* ** ya que tendremos que recorrer la lista elemeento tras elemento hasta encontrar la posicion en la que debemos insertar el dato en cuestión.

#####4.3.1.4 Pseudo-algoritmo
	public void add(T elem) {
        Nodo<T> actual;
        Nodo<T> auxN = nuevo Nodo<T>(elem);
        booleano enc = false;

        si (cont == 0 ? true : false){
        	ultimo = auxN;
            auxN.sig = auxN;
        }
        sino{
        	actual = ultimo.sig;
            si(actual.info.compararCon(elem)){
            	auxN.sig = ultimo.sig;
                ultimo.sig = auxN;
            }
            sino si(ultimo.info.compararCon(elem)<0){
            	auxN.sig = ultimo.sig;
                ultimo.sig = auxN;
                ultimo = auxN
            }
            sino{
            	mientras(!enc){
                	if(current.info.compararCon(elem)<0 && actual.sig.info.compararCon(elem) > 0){
                    	auxN.sig = actual.sig;
                        actual.sig = auxM;
                        enc = true;
                    }
                }
            }
        }
        cont++;
    }


#####4.3.1.5 Método final
```java
public void add(T elem) {
        Node<T> current;    //pointer
        Node<T> auxNode = new Node<T>(elem); //auxiliar pointer
        boolean finded = false; //flag for while

        if (count == 0 ? true : false) {//if it's empty
            last = auxNode;
            auxNode.next = auxNode;
        } else {
            current = last.next;//first element
            if (current.data.compareTo(elem) > 0) {//if the first is > elem
                auxNode.next = last.next;
                last.next = auxNode;

            } else if (last.data.compareTo(elem) < 0) {//if the last < auxNode
                auxNode.next = last.next;
                last.next = auxNode;
                last = auxNode;
            } else { //between two elements
                while (!finded) {
                    if (current.data.compareTo(elem) < 0 && current.next.data.compareTo(elem) > 0) { //if whe've finded where to insert
                        auxNode.next = current.next;
                        current.next = auxNode;
                        finded = true;
                    }
                    current = current.next;
                }
            }
        }
        count++;
    }
```

### 4.4. StringQuickSort (Nueva implementación)

#### 4.4.1 QuickSort (Nueva implementación)

#####4.4.1.1 Precondición/Postcondición

- ++Pre++: Tenemos una lista que queremos ordenar (en ocasiones puede estar casi ordenada o puede llamarse de nuevo a la función de ordenación y por lo tanto estar totalmente ordenada)
- ++Post++: Devolveremos la lista que recibimos como parámetro una vez ordenada por (Nombre, Apellido)

#####4.4.1.2 Casos de prueba

- Lista vacía
- Lista no vacía

#####4.4.1.3 Coste

En el mejor caso, el pivote termina en el centro de la lista, dividiéndola en dos sublistas de igual tamaño. En este caso, el orden de complejidad del algoritmo es O(n·log n) .
En el peor caso, el pivote termina en un extremo de la lista. El orden de complejidad del algoritmo es entonces de O(n²) . El peor caso dependerá de la implementación del algoritmo, aunque habitualmente ocurre en listas que se encuentran ordenadas, o casi ordenadas.
En el caso promedio, el orden es O(n·log n) .

#####4.4.1.4 Pseudo algoritmo

	public void quickSort(T[] laTabla){
		quickSort(laTabla, 0, laTabla.length-1);
	}

	private void quickSort(T[] tabla, int inicio, int fin){
		if ( fin - inicio > 0 ) { // hay más de un elemento en la tabla
		int indiceParticion = particion(tabla, inicio, fin);
		quickSort(tabla, inicio, indiceParticion - 1);
		quickSort(tabla, indiceParticion + 1, fin);
	}

	private int particion(T[] tabla, int i, int f){
		T pivote = tabla[i];
		int izq = i;
		int der = f;
		while ( izq < der ){
			while ( tabla[izq].compareTo(pivote) <= 0 && izq < der)
				izq++;
			}
			while ( tabla[der].compareTo(pivote) > 0 )
				der--;
			}
        	if ( izq < der ){
				swap(tabla, izq, der);
			}
		}
		tabla[i] = tabla[der];
		tabla[der] = pivote;
		return der;
	}


#####4.4.1.5 Método final

```java
public static void quickSort(String[] table){
        quickSort(table, 0, table.length-1);
    }

    private static void quickSort(String[] table, int start, int end){
        if(end-start > 0){
            int partitionIndex = partition(table, start, end);
            quickSort(table, start, partitionIndex-1);
            quickSort(table, partitionIndex + 1, end);
        }
    }

    private static int partition(String[] table, int s, int e){
        String pivote = table[s];
        int left = s;
        int right = e;

        while(left < right){
            while(table[left].compareTo(pivote) <= 0 && left<right){
                left++;
            }
            while(table[right].compareTo(pivote) > 0){
                right--;
            }
            if(left < right){
                swap(table, left, right);
            }
        }
        table[s]=table[right];
        table[right] = pivote;

        return right;
    }

    public static void swap(String[] table, int l, int r){
        String temp = table[l];
        table[l] = table[r];
        table[r] = temp;
```

## 5. Código

El resto de las clases se entregan en una carpeta que contiene las clases necesarias de la primera actividad anexas a las de la segunda y junto a todas, se encuentra una carpeta con los test que entregaste modificados por nosotros para hacerlos más personales.

### 5.1 Clase Actor

```java

package lab2;

/**
 * Created by Josu on 25/09/2016.
 */
public class Actor {

    private String name;
    private String surname;
    private FilmList filmL;

    public Actor(String pName, String pSurname) {
        this.name = pName;
        this.surname = pSurname;
        this.filmL = new FilmList();
    }

    public FilmList getFilmList() {
        return this.filmL;
    }

    public String getName() {
        return this.name;
    }

    public String getSurname() {
        return this.surname;
    }
}

```

### 5.2 Clase ActorCatalog

```java

package lab2;

import java.util.HashMap;

/**
 * Created by Josu on 25/09/2016.
 */
public class ActorCatalog {

    private static ActorCatalog myActorCatalog;
    private HashMap<String, Actor> actorL;

    private ActorCatalog() {
        this.actorL = new HashMap<>();
    }

    public static ActorCatalog getmyActorCatalog() {
        if (myActorCatalog == null) {
            myActorCatalog = new ActorCatalog();
        }
        return myActorCatalog;
    }

    public HashMap<String, Actor> getActorL() {
        return this.actorL;
    }

    private boolean exist(String pActorName, String pActorSurname) {
        return actorL.get(pActorName + " " + pActorSurname) != null;
    }

    public void addActor(Actor pActor) {
        if (!this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.put(pActor.getName() + " " + pActor.getSurname(), pActor);
        }
    }

    public Actor searchActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            return this.actorL.get(pActor.getName() + " " + pActor.getSurname());
        }
        return null;
    }

    public void removeActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.remove(pActor.getName() + " " + pActor.getSurname());
            System.out.println("Actor erased");
        } else {
            System.out.println("Actor not found");
        }
    }

    public String[] quickSortList() {
        String[] auxS = new String[actorL.size()];
        int i = 0;
        for (String key : actorL.keySet()) {
            auxS[i] = key;
            i++;
        }
        StringQuickSort.sort(auxS);
        return auxS;
    }

    public void printList(String[] auxS) {
        for (String key : auxS) {
            System.out.println(key);
        }
    }

    public int getSize(){
        return this.actorL.size();
    }

    public int getTotalFilms(){
        int cont = 0;
        for (String key : this.actorL.keySet()){
            cont += this.actorL.get(key).getFilmList().getTotalFilms();
        }
        return cont;
    }
}

```

### 5.3 Clase ActorList (Implementación de UnorderedCircularLinkedList)

``` java
package lab2;


import java.util.Iterator;

/**
 * Created by david on 25/09/2016.
 */
public class ActorList {

    private UnorderedCircularLinkedList<Actor> actorList;


    public ActorList() {
        this.actorList = new UnorderedCircularLinkedList<>();
    }


    public boolean exist(String pActorName, String pActorSurname) {
        return this.actorList.contains(new Actor(pActorName, pActorSurname));
    }

    public void addActor(Actor auxActor) {
        if (!this.exist(auxActor.getName(), auxActor.getSurname())) {
            this.actorList.addToRear(auxActor);
        }
    }

    public Actor getActor(String pActorName, String pActorSurname) {
        if (this.exist(pActorName , pActorSurname)) {
            return actorList.find(new Actor(pActorName,pActorSurname));
        }
        return null;
    }

    public void removeActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorList.remove(new Actor(pActor.getName() , pActor.getSurname()));
        }
    }

    public void printActors() {
        System.out.println("These are all the actors: ");
        Iterator<Actor> itr = this.actorList.iterator();

        if (this.actorList.isEmpty()) {
            System.err.println(" No consta ningun actor");
        } else {
            while (itr.hasNext()) {
                Actor act = itr.next();
                System.out.println(act.getName()+" "+act.getSurname());
            }
        }
    }

    public int getActorsNumber(){
        return this.actorList.count;
    }


}
```

### 5.4 Clase CircularLinkedList

```java
package lab2;

import java.util.Iterator;

/**
 * @author Josu on 27/10/2016
 */
public class CircularLinkedList<T> implements ListADT<T> {

    // Atributos
    protected Node<T> first;
    protected Node<T> last; // apuntador al ultimo
    protected String descr;  // descripci�n
    protected int count;

    // Constructor
    public CircularLinkedList() {
        last = null;
        descr = "";
        count = 0;
    }

    public void setDescr(String nom) {
        descr = nom;
    }

    public String getDescr() {
        return descr;
    }

    public T removeFirst() {
        // Elimina el primer elemento de la lista
        // Precondici�n: la lista tiene al menos un elemento
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE

        // Elimina el primer elemento de la lista
        // Precondici�n: la lista tiene al menos un elemento
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE

        Node<T> first = last.next;
        if (size() == 1) {
            last = null;
        } else {
            last.next = last.next.next;
        }
        count--;
        return first.data;
    }

    public T removeLast() {
        // Elimina el �ltimo elemento de la lista
        // Precondici�n: la lista tiene al menos un elemento
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE
        Node<T> pLast = last;
        if (size() == 1) {
            last = null;
        } else {
            Node<T> current = last.next;
            while (current.next != last) {
                current = current.next;
            }
            last = current;
            last.next = last.next.next;
        }
        count--;
        return pLast.data;
    }

    /*
    pre: tenemos una lista de elementos. es posible que la lista es vacia.
    post: tenemos una lista de elementos a la que le hemos eliminado el elemento que recibimos en caso de que este eista previamente
     */
    public T remove(T elem) {
        Node<T> current = last;
        int i = 0;
        T returnNum;

        if (this.isEmpty()){ return null;} //if its empty we return null
        else{//if not null
            while(!current.next.data.equals(elem) && i!=size()){//goes out when finds the element or overpass the size
                current = current.next;
                i++;
            }
            if (i==count){//if the elemente isn't finded
                System.out.println("The element isn't finded");
                return null;
            }else{//we find it. we have to remove currents pointing node
                if (count == 1){//if we only have one element
                    returnNum = last.data;
                    last = null;
                }else{//if are more elements than 1
                    returnNum = current.next.data;

                    if (current.next == last) {
                        last = current;//if the element is the last we dont lose the pointer, we give it to the previous item
                    }
                    current.next = current.next.next;
                }
                count--;
                System.out.println("\n ->  "+elem+" it's been deleted");
                return returnNum;
            }
        }
    }

    public T first() {
        //Da acceso al primer elemento de la lista
        if (isEmpty())
            return null;
        else return last.next.data;
    }

    public T last() {
        //Da acceso al �ltimo elemento de la lista
        if (isEmpty())
            return null;
        else return last.data;
    }

    public boolean contains(T elem) {
        if (isEmpty()) {
            return false;
        }

        Node<T> current = last.next; // Empieza con el primer elemento

        while ((current != last) && !elem.equals(current.data))
            current = current.next;
        return elem.equals(current.data);
    }

    public T find(T elem) {
        //Determina si la lista contiene un elemento concreto, y develve su referencia, null en caso de que no est�
        // COMPLETAR EL CODIGO Y CALCULAR EL COSTE
        Integer i = 0;
        T returnNum;
        Node<T> current = last;

        if(this.isEmpty()){
            return null;
        }
        else{//si hay elementos, buscamos nuestro elemento
            while(!current.data.equals(elem) && i!=size()){//tiene que salir si recorre todos los elementos
                current = current.next;
                i++;
            }
            if(i==count){//no lo ha encontrado
                return null;
            }
            else{//lo a encontrado
                returnNum = current.data;
                return returnNum;
            }

        }
    }

    public boolean isEmpty() {
        return last == null;
    }

    //Determina el n�mero de elementos de la lista
    public int size() {
        return count;
    }

    /**
     * Return an iterator to the stack that iterates through the items .
     */
    public Iterator<T> iterator() {
        return new ListIterator();
    }

    // an iterator, doesn't implement remove() since it's optional
    private class ListIterator implements Iterator<T> {

        private Node<T> current;
        private int cont;

        public ListIterator(){
            current = last.next;
            cont = count;
        }

        public boolean hasNext(){
            boolean a = cont==0?false:true;
            return a;
        }

        public T next(){
            T content = null;
            if (current != null) {
                content = current.data;
                current = current.next;
                cont--; //mover al metdo next
            }
            return content;
        }

    }

    public void visualizarNodos() {
        System.out.print(this.toString()+" ");
    }

    @Override
    public String toString() {
        String result = new String();
        Iterator<T> it = iterator();
        while (it.hasNext()) {
            T elem = it.next();
            result = result + "[" + elem.toString() + "] \n";
        }
        return "SimpleLinkedList " + result + "]";
    }
}
```

### 5.5 Clase FileManager (El método de exportación ha sufrido cambios)

```java
package lab2;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by david on 25/09/2016.
 */
public class FileManager {

    private static FileManager myFileManager;

    private FileManager() {
    }

    public static FileManager getMyFileManager() {
        if (myFileManager == null) {
            myFileManager = new FileManager();
        }
        return myFileManager;
    }

    public static int countLines(File pFile) throws IOException {
        LineNumberReader lnr = new LineNumberReader(new FileReader(pFile));
        lnr.skip(Long.MAX_VALUE);
        lnr.close();
        return lnr.getLineNumber() + 1;//Add 1 because line index starts at 0
    }


    public void readFile(int pOption) throws IOException {

        String[] auxLine1;

        long startTime = System.currentTimeMillis();

        int j = 0; //j= counts the actual line of file
        int total = 0; //total = saves total running time of reading
        int auxCont = 0;  //auxCount = saves the percentage of reading of file

        try (InputStream resource = FileManager.class.getResourceAsStream("testAllActors.txt")) {

            int contLines = countLines(new File("/Users/Josu/IdeaProjects/EDA16-17/src/lab2/testAllActors.txt"));

            String filmName, actorName, actorSurname;

            String[] auxLine2;

            Film auxFilm;

            List<String> lines = new BufferedReader(new InputStreamReader(resource, StandardCharsets.UTF_8)).lines().collect(Collectors.toList());

            for (String line : lines) {

                auxLine1 = line.split("\\s+\\--->+\\s"); //we split to get the name of the movie

                if (pOption == 1) {
                    NormalizeStrings.getMyNormalizeString().run(auxLine1);
                }

                filmName = auxLine1[0]; //here we save the name of the film

                auxLine2 = auxLine1[1].split("\\s+\\&&&+\\s"); //we split the array of actors in

                auxFilm = new Film(filmName); //create a new film

                if (pOption == 1) {
                    if (!auxFilm.getName().contains("�")) {
                        FilmCatalog.getMyFilmCatalog().addFilm(auxFilm); //we add the film if its not been added before
                    }
                } else {
                    FilmCatalog.getMyFilmCatalog().addFilm(auxFilm); //we add the film if its not been added before
                }

                int i = 0;

                while (auxLine2.length > i) { // mientras el indice no sea mayor que el tamaño de la lista(indexOutOfBoundException)

                    actorSurname = "";
                    actorName = auxLine2[i];

                    if (actorName.contains("(")) {
                        auxLine1 = actorName.split("\\s\\(");
                        actorName = auxLine1[0];
                    }
                    if (actorName.contains(",")) {//convertimos -> Apellido, Nombre --> Nombre, Apellido (como es habitual)
                        auxLine1 = actorName.split(",\\s*");
                        if (auxLine1.length > 1) {
                            if (auxLine1[1].compareToIgnoreCase("null") != 0) {
                                actorSurname = auxLine1[0];
                                actorName = auxLine1[1];
                            } else {
                                actorName = auxLine1[0];
                            }
                        }
                    }
                    Actor auxActor = new Actor(actorName, actorSurname);//Creamos la pelicula enviandole el nombre una vez normalizado

                    if (pOption == 1) {
                        if (!auxActor.getName().contains("�")) {
                            if (auxActor.getName().charAt(0) > 'A' && auxActor.getName().charAt(0) < 'Z') {
                                auxActor.getFilmList().addFilm(auxFilm);
                                ActorCatalog.getmyActorCatalog().addActor(auxActor);
                                if (!auxFilm.getName().contains("�")) {
                                    FilmCatalog.getMyFilmCatalog().getFilm(auxFilm.getName()).getActorList().addActor(auxActor);
                                }
                            }
                        }
                    } else {
                        auxActor.getFilmList().addFilm(auxFilm);
                        ActorCatalog.getmyActorCatalog().addActor(auxActor);
                        FilmCatalog.getMyFilmCatalog().getFilm(auxFilm.getName()).getActorList().addActor(auxActor);
                    }

                    i++;

                }
                if (j == 0) {
                    System.out.println("\t[*] 0% file readed");
                }
                j++;

                if (((j * 100) / contLines) % 5 == 0) {
                    if (((j * 100) / contLines) != auxCont) {
                        auxCont = ((j * 100) / contLines);
                        long stopTime = System.currentTimeMillis();
                        total = (int) (stopTime - startTime) / 1000;

                        System.out.println("\t[*] " + auxCont + "% file readed. Time elapsed: " + total + "s");
                    }
                } else if (((j * 100) / contLines) % 5 == 0) {
                    SwingGUI.getMyJMenu().updateBar((j * 100) / contLines);
                }
            }
            System.out.println("\t[*] 100% file readed. Time elapsed: " + total + "s");
        }
        System.out.println("\t-------- File read finished --------\n");
        System.out.println("\t--- Elapsed time to read the file ---> " + total + "s---");

        System.out.println("\t--- Total actor/actresses found :" + ActorCatalog.getmyActorCatalog().getActorL().size()+" ---");
        System.out.println("\t--- Total films found : " + FilmCatalog.getMyFilmCatalog().getSize()+" ---");

        float avActorsFilm = (float)FilmCatalog.getMyFilmCatalog().getTotalActors()/(float)FilmCatalog.getMyFilmCatalog().getSize();
        System.out.printf("\t--- Average actors per film: %.2f",avActorsFilm);
        double avFilmsActor = (double)ActorCatalog.getmyActorCatalog().getTotalFilms()/(double)ActorCatalog.getmyActorCatalog().getSize();
        System.out.print("---\n");
        System.out.printf("\t--- Average films per actor: %.2f", avFilmsActor);
        System.out.print("---\n");

    }

   @SuppressWarnings("rawtypes")
    public void exportToFile() {

        String[] keys = ActorCatalog.getmyActorCatalog().quickSortList();

        FileWriter fichero = null;
        PrintWriter pw;

        long timeStart = System.currentTimeMillis();

        try {
            String directorio = System.getProperty("user.dir");//cogemos variable entorno
            fichero = new FileWriter(directorio + "/ActorList_ordered.txt");
            pw = new PrintWriter(fichero);

            int i = 1;
            for (int i1 = 0, keysLength = keys.length; i1 < keysLength; i1++) {
                Object key = keys[i1];
                pw.print("Actor " + i + " -> ");
                pw.println(ActorCatalog.getmyActorCatalog().getActorL().get(key).getName() + " " + ActorCatalog.getmyActorCatalog().getActorL().get(key).getSurname());
                Object[] keys2;
                Iterator<Film> itr = ActorCatalog.getmyActorCatalog().getActorL().get(key).getFilmList().getIterator();
                while (itr.hasNext()) {
                    Film auxFilm = itr.next();
                    pw.println("\t" + ActorCatalog.getmyActorCatalog().getActorL().get(key).getFilmList().getFilmL().find(auxFilm).getName());
                }
                i++;
                int percentage = (i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size();
                if (((i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size()) % 5 == 0) {
                    if (((i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size()) != percentage) {
                        System.out.println("\t\t[*] " + percentage + "%");
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != fichero) {
                    fichero.close();
                }
                long timeTotal = (System.currentTimeMillis() - timeStart);
                System.out.println("\t\t --- Elapsed time to export the file --- : " + (int) timeTotal / 1000 + "sec, " + timeTotal * 1000 + "ms\n");
                System.out.println("\n\tFile exported to: " + System.getProperty("user.dir"));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
}
```

### 5.6 Clase Film (implementada interfaz Comparable<T>)

```java
package lab2;

/**
 * Created by david on 25/09/2016.
 */
public class Film implements Comparable<Film> {

    private String name;
    private int earned = 0;
    private ActorList actorList;

    public Film(String pName) {
        this.name = pName;
        this.actorList = new ActorList();
    }

    public String getName() {
        return this.name;
    }

    public int getEarned() {
        return this.earned;
    }

    public void incrementEarned(int auxEarned) {
        this.earned += auxEarned;
    }

    public ActorList getActorList() {
        return this.actorList;
    }


    @Override
    public int compareTo(Film pFilm) {
        return this.getName().compareToIgnoreCase(pFilm.getName());
    }
}
```

### 5.7 Clase FilmCatalog 

```java
package lab2;

import java.util.HashMap;

/**
 * Created by Josu on 25/09/2016.
 */
public class FilmCatalog {

    private static FilmCatalog myFilmCatalog;
    private HashMap<String, Film> filmL;

    private FilmCatalog() {
        this.filmL = new HashMap<>();
    }

    public static FilmCatalog getMyFilmCatalog() {
        if (myFilmCatalog == null) {
            myFilmCatalog = new FilmCatalog();
        }
        return myFilmCatalog;
    }

    public boolean exist(String pFilmName) {
        return filmL.get(pFilmName) != null;
    }

    public void addFilm(Film pFilm) {
        if (!this.exist(pFilm.getName())) {
            this.filmL.put(pFilm.getName(), pFilm);
        }
    }

    public Film getFilm(String pFilmName) {
        if (this.exist(pFilmName)) {
            return this.filmL.get(pFilmName);
        }
        return null;
    }

    public int getSize(){
        return this.filmL.size();
    }

    public int getTotalActors(){
        int cont = 0;
        for (String key : filmL.keySet()){
            cont += this.filmL.get(key).getActorList().getActorsNumber();
        }
        return cont;
    }

}
```

### 5.8 Clase FilmList (Implementación de OrderedCircularLinkedList)

```java
package lab2;

import java.util.Iterator;

/**
 * Created by Josu on 25/09/2016.
 */
public class FilmList {

    private OrderedCircularLinkedList<Film> filmL;

    public FilmList() {
        this.filmL = new OrderedCircularLinkedList<>();
    }

    public Iterator<Film> getIterator(){ return this.filmL.iterator();}

    private boolean exist(String pFilmName) {
        return this.filmL.contains(new Film(pFilmName));
    }

    public void addFilm(Film pFilm) {
        if (!this.exist(pFilm.getName())) {
            this.filmL.add(pFilm);
        }
    }

    public Film getFilm(String pFilmName) {
        if (this.exist(pFilmName)) {
            return this.filmL.find(new Film(pFilmName));
        }
        return null;
    }

    public OrderedCircularLinkedList<Film> getFilmL() {
        return this.filmL;
    }

    public void printFilms() {
        System.out.println("These are all the films: ");
        Iterator<Film> itr = this.filmL.iterator();

        if (this.filmL.isEmpty()) {
            System.err.println(" No consta ningun actor para esta pelicula");
        } else {
            while (itr.hasNext()) {
                Film film = itr.next();
                System.out.println(film.getName());
            }
        }
    }

    public int getTotalFilms(){
        return this.filmL.count;
    }
}
```

### 5.9 Clase OrderedCircularLinkedList

```java

/**
 * Created by Josu on 24/10/2016.
 */
package lab2;

public class OrderedCircularLinkedList<T extends Comparable<T>> extends CircularLinkedList<T> implements OrderedListADT<T> {

    public void add(T elem) {
        Node<T> current;    //pointer
        Node<T> auxNode = new Node<T>(elem); //auxiliar pointer
        boolean finded = false; //flag for while

        if (count == 0 ? true : false) {//if it's empty
            last = auxNode;
            auxNode.next = auxNode;
        } else {
            current = last.next;//first element
            if (current.data.compareTo(elem) > 0) {//if the first is > elem
                auxNode.next = last.next;
                last.next = auxNode;

            } else if (last.data.compareTo(elem) < 0) {//if the last < auxNode
                auxNode.next = last.next;
                last.next = auxNode;
                last = auxNode;
            } else { //between two elements
                while (!finded) {
                    if (current.data.compareTo(elem) < 0 && current.next.data.compareTo(elem) > 0) { //if whe've finded where to insert
                        auxNode.next = current.next;
                        current.next = auxNode;
                        finded = true;
                    }
                    current = current.next;
                }
            }
        }
        count++;
    }
}
```

### 5.10 Clase StringQuickSort

```java
package lab1;

/**
 * Created by David on 24/10/2016.
 */
public class StringQuickSort {


    public static void quickSort(String[] table){
        quickSort(table, 0, table.length-1);
    }

    private static void quickSort(String[] table, int start, int end){
        if(end-start > 0){
            int partitionIndex = partition(table, start, end);
            quickSort(table, start, partitionIndex-1);
            quickSort(table, partitionIndex + 1, end);
        }
    }

    private static int partition(String[] table, int s, int e){
        String pivote = table[s];
        int left = s;
        int right = e;

        while(left < right){
            while(table[left].compareTo(pivote) <= 0 &&  left<right){
                left++;
            }
            while(table[right].compareTo(pivote) > 0){
                right--;
            }
            if(left < right){
                swap(table, left, right);
            }
        }
        table[s]=table[right];
        table[right] = pivote;

        return right;
    }

    public static void swap(String[] table, int l, int r){
        String temp = table[l];
        table[l] = table[r];
        table[r] = temp;
    }
```

### 5.11 Clase TerminalUI

```java
package lab2;

import java.io.*;
import java.util.Scanner;

/**
 * Created by Josu on 26/09/2016.
 */
public class TerminalUI {

    private static TerminalUI myTerminalGUI;
    private Scanner optMenu;

    private TerminalUI() {
        optMenu = new Scanner(System.in);
    }

    public static TerminalUI getMyTerminalGUI() {
        if (myTerminalGUI == null) {
            myTerminalGUI = new TerminalUI();
        }
        return myTerminalGUI;
    }

    public static void main() throws FileNotFoundException {

        String[] auxActorArray;
        String auxActorName;
        String auxActorSurname;

        String auxS;

        System.out.println("\t\t\t***-----Welcome to our IMDb EDA16/17 project menu-----***");

        System.out.println("\n\n ** We use OrderedCircularLinkedList for the list of films per actor, for the list of");
        System.out.println("actors per film we decide to use UnorderedCircularLinkedList. ActorCatalog and FilmCatalog");
        System.out.println("are still using HashMap<String,Actor> and HashMap<String,Film> respectively **");

        do {
            System.out.println("\n\t\t\t----------MENU----------");
            System.out.println("\t\t1) Read data from file");
            System.out.println("\t\t2) Search for an actor/actress");
            System.out.println("\t\t3) Add a new actor/actress");
            System.out.println("\t\t4) Search for films of a particular actor");
            System.out.println("\t\t5) Search for actor of a particular film");
            System.out.println("\t\t6) Increase the money raised by a film");
            System.out.println("\t\t7) Erase an actor/actress");
            System.out.println("\t\t8) Obtain an ordered list of actor (name,surname)");
            System.out.println("\t\t9) Save/Export the new list to a file");

            int optMenu = Keyboard.getMyKeyboard().getInt();

            switch (optMenu) {
                case 0:
                    System.out.println("\t\t--- Saliendo del programa... ----");
                    break;
                case 1:
                    try {
                        System.out.println("\tSelect one of options below: ");
                        System.out.println("\t\t1) Read only the 'readable' actors/films (after trying to rescue some names from the codification, take only the 'full readables') ");
                        System.out.println("\t\t2) Read the full list of actors/movies (don't care if they're wrong written, after running our conversor");
                        int optMenu1 = 0;
                        while (optMenu1 < 1 || optMenu1 > 2) {
                            optMenu1 = Keyboard.getMyKeyboard().getInt();
                            if (optMenu1 == 1) {
                                FileManager.getMyFileManager().readFile(1);
                            } else if (optMenu1 == 2) {
                                FileManager.getMyFileManager().readFile(2);
                            } else {
                                System.out.println("Invalid option, try again. Select a number between 1-2 range");
                            }
                        }

                    } catch (FileNotFoundException e1) {
                        System.out.println("File not found. ¿Are you sure that you're opening the correct file?");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 2:
                    System.out.println("Enter the name of the actor you want to look for: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    Actor auxA = ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname));
                    if (auxA == null) {
                        System.out.println("Actor not finded: " + auxS);
                    } else {
                        System.out.println("Actor finded: " + auxA.getName());
                    }
                    break;
                case 3:
                    System.out.println("Enter the name of the actor that you want to add: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    if (ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)) != null) {
                        System.out.println("Actor: " + auxS + " already exist");
                    } else {
                        ActorCatalog.getmyActorCatalog().addActor(new Actor(auxActorName, auxActorSurname));
                        System.out.println("Actor: " + auxS + " added to the ActorCatalog");
                    }
                    break;
                case 4:
                    System.out.println("Enter the name of the actor whose films you want to know");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    if (ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)) != null) {
                        ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)).getFilmList().printFilms();
                    } else {
                        System.out.println("Actor: " + auxS + " do not exist in the ActorCatalog");
                    }
                    break;
                case 5:
                    System.out.println("Enter the film whose actors that do you want to know: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    if (FilmCatalog.getMyFilmCatalog().getFilm(auxS) != null) {
                        FilmCatalog.getMyFilmCatalog().getFilm(auxS).getActorList().printActors();
                    }
                    break;
                case 6:
                    System.out.println("Enter the film whose amount of earning you want to raise: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    System.out.println("Enter the amount of money that you want to increase: ");
                    int auxI = Keyboard.getMyKeyboard().getInt();
                    if (FilmCatalog.getMyFilmCatalog().exist(auxS)) {
                        FilmCatalog.getMyFilmCatalog().getFilm(auxS).incrementEarned(auxI);
                        System.out.println("Total earned by the film: " + FilmCatalog.getMyFilmCatalog().getFilm(auxS).getEarned());
                    } else {
                        System.out.println("File not found. Are you sure that you have written title correctly?");
                    }
                    break;
                case 7:
                    System.out.println("Enter the name of the actor that you want to remove");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    if (ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)) != null) {
                        ActorCatalog.getmyActorCatalog().removeActor(new Actor(auxActorName, auxActorSurname));
                        System.out.println("Actor: " + auxS + " succesfully removed");
                    } else {
                        System.out.println("Actor: " + auxS + " do not exist in the ActorCatalog");
                    }
                    break;
                case 8:
                    System.out.println("Do you want to print (console) the ordered list of actors?");
                    if (Keyboard.getMyKeyboard().getString().equalsIgnoreCase("y")){
                        ActorCatalog.getmyActorCatalog().printList(ActorCatalog.getmyActorCatalog().quickSortList());
                    break;
                    }
                        ActorCatalog.getmyActorCatalog().quickSortList();
                    break;
                case 9:
                    FileManager.getMyFileManager().exportToFile();
                    break;
            }
        } while (1 != 0);
    }
}

```

### 5.12 UnorderedCircularLinkedList

```java
package lab2;

/**
 * @author Josu on 27/10/2016
 * @author David on 27/10/2016
 */
public class UnorderedCircularLinkedList<T> extends CircularLinkedList<T> implements UnorderedListADT<T> {

    /*Pre: We have a list, empty or not
    * Post: We have added the element to the first position of the list*/
	public void addToFront(T elem){
        //System.out.println("AÑADIMOS el elemento "+elem+" a la PRIMERA POSICION de la lista");

        Node<T> newNode = new Node<T>(elem);
		if(isEmpty()){
			last = newNode;
            last.next = last;
		}
		else{
			newNode.next = last.next;
			last.next = newNode;
		}
		count++;
	}

    /* Pre: We have a list, empty or not
    *  Post: We've added the element to the last position*/
	public void addToRear(T elem) {
        //System.out.println("AÑADIMOS el elemento "+elem+" a la ULTIMA POSICION de la lista");

		Node<T> newNode = new Node<T>(elem);
		if(isEmpty()){
			last = newNode;
			last.next = last;
		}else{
			newNode.next = last.next; //the next of 'our' rear points firts
			last.next = newNode; //the next of the previous last points our 'rear' node
			last = newNode;
		}
		count++;
	}
	/* Pre: We have a list, we must have at least one element. We receive the element that we want to add and the target to add after
	 * Post: We have added our element after the target element of the list */
	public void addAfter(T elem, T target) {

        //System.out.println("Añadimos el elemento "+elem+" tras el elemento "+target+"\n");

        Node<T> newNode = new Node<T>(elem);
		Node<T> current = last;

		while(!current.data.equals(target)){
			current = current.next;
		}

		newNode.next = current.next;
		current.next = newNode;

		count++;

	}

}
```

## 6. Resultados de las pruebas

**Estos son los resultados de las pruebas**, en la etapa final de desarrollo (lo que estamos entregando) de la actividad. **Todos los tiempos que mostramos son medias** realizadas (entre 5-10 ejecuciones) **de la misma operación**. Las pruebas **se han realizado en diferentes equipos con diferentes sistemas operativos**, detallamos:

En el fichero normalizado encontramos **1 061 522** actores, **230 369** peliculas.
En el fichero sin normalizar (cogiento toda la informacion, independientemente de si estan bien escritos) encontramos **1 191 316** actores, **238 809** peliculas.

	- Media de actores por pelicula
		* 11,91 actores en el fichero normalizado
		* 13,78 actores en el fichero sin normalizar
	- Media de peliculas por actor**: 1.0 en ambas pruebas (fichero normalizado y no normalizado)

- **CPU**: Intel i5 6600K 3,9 GHz x 4 cores, **GPU:** nVidia GTX 970 4GB Strix,**RAM:** 16GB DDR5  2666, **SO:** *Windows 10 Pro x64*
	- Cargar fichero normalizado: 7sec (4s menos que el lab1)
	- Cargar fichero completo: 8sec (3s menos que el lab1)
	- Ordenar lista normalizada de actores: 0sec, 609000ms
	- Ordenar lista completa de actores: 0sec, 688000ms
	- Exportar lista normalizada de actores: 1sec, 1282000ms
	- Exportar lista completa de actores: 1sec, 1672000ms

- **CPU**: Intel i5 2,7 GHz x 2 cores, **GPU:** HD 6100,**RAM:** 8GB LPDDR3  1866, **SO:** *Mac OS Sierra (10.12)*
	- Cargar fichero normalizado: 16sec (4s menos que el lab1)
	- Cargar fichero completo: 18sec (8s menos que el lab1)
	- Ordenar lista normalizada de actores: 1sec, 1398000ms
	- Ordenar lista completa de actores: 1sec, 1376000ms
	- Exportar lista normalizada de actores: 4sec, 12976000ms (8s menos que el lab1)
	- Exportar lista completa de actores: 9sec, 21158000ms (12s menos que el lab1)

- **CPU**: Intel Atom Z3775 1,46 GHz x 2 cores, **GPU:** Intel HD Graphics (Bay Trail) (311 - 778 MHz),**RAM:** 2GB RAM 1333, **SO:** *Windows 10 Home x32*
	- Cargar fichero normalizado: 68sec
	- Cargar fichero completo: El ordenador no es capaz de leerlo
	- Ordenar lista normalizada de actores: 2sec, 2312000ms
	- Ordenar lista completa de actores: No es capaz de leer el fichero completo
	- Exportar lista normalizada de actores: 78sec, 78051000ms
	- Exportar lista completa de actores: No es posible leer el fichero completo

## 7. Conclusiones

Volvemos a destacar, **la importancia de las búsquedas en el funcionamiento de nuestro programa.  **Al tener que trabajarlas tanto, es necesario optimizarlas al máximo para evitar tiempos de ejecución demasiado altos.

**Destacar la dificultad añadida de trabajar con datos 'T' para hacer el metodo de adición de la lista OrderedCircularLinkedList**. Aunque finalmente entendimos como trabajar con la Interfaz Comparable<T> y nos sentimos mucho mas cómodos, pudiendo asi implementar dicha lista en FilmList.

**Otro de los métodos con mucha importancia es cargarFichero()** dado que coge línea a línea el texto que hay en el fichero y lo trata. Es decir, elimina toda la información no relevante para el programa y añade la que si tiene importancia.

**Tras analizar el fichero y destacar un patrón que pudiera servirnos** para, basandonos en el metodo split (de la clase String), separar las lineas del documento en información que nos fuera mas sencilla de manejar; **nos centramos en optimizar al máximo el funcionamiento de esta carga**.
Para realizar la operacion de una forma mas transparente al usuario y sin saturar la ventana de la consola,** hemos desarrollado un metodo que calcula el procentaje actual del documento y la imprime por pantalla en bloques de 10% en 10%** y sin repetirse ninguna de las impresiones.
Así mismo, **hemos implementado programación basada en multiples procesos para aligerar la carga del fichero con la opción de normalización de nombres que hemos decidido aportar**. Las diferencias las detallaremos ahora con mas datos.



