#Practica. Actividad 4.
				UPV-EHU 2016/2017
                            
                            
                            
                Estructuras de Datos y Algoritmos
                          

              
              
                
                
                											Josu Alvarez
                                                            David Max

* * *
##Indice

Mas informacion en la pagina web del proyecto: [GITHUB](http://txusyk.github.io/EDA16-17/): http://txusyk.github.io/EDA16-17/

[TOC]

* * *

##1. Introducción

**Dado un fichero de datos** que contiene actores y actrices de Internet Movie DataBase (IMDB), con una estructura efinida ('nombrePelicula' ---> 'nombreActor1' &&& 'nombreActor2'...) . **Se ha de implementar un programa que cargue el fichero de datos y extraiga del mismo los nombres de los actores y las peliculas que contiene**.

**El pilar del funcionamiento de nuestro programa son las búsquedas**. Dado que tanto para añadir, eliminar como para gestionar alguno de los datos previamente se hará una búsqueda para comprobar si realmente existe.

Dado que disponiamos de tiempo y que el proyecto nos ha parecido interesante, **hemos decidido implementar ciertas mejoras sobre el trabajo inicial**, siendo estas:

- ** El sistema dará la opción** al usuario para que decida como quiere ejecutar el programa, si por la **consola o bien mediante una GUI** que hemos construido con Swing.
- **Hay dos formas de cargar el archivo**, una **con todos los datos y** otra **con los datos normalizados** (se explica mejor en las proximas lineas).
- **Todo el proyecto** y todas sus versiones estan **siendo manejadas mediante GitHub**, se ha dispuesto una pagina web publica que contiene esta misma información y será actualizada con cada una de las proximas entregas.
- **Uso exclusivo de lenguaje 'Markdown' para proceder a documentar el codigo**. En nuestro esfuerzo por usar tecnologías libres y ser eficientes, hemos encontrado este lenguaje ideal (dada su total compatibilidad con las wikis y las webs de GitHub).
- **Uso del ingles** siempre que nos ha sido posible, para desarrollar el codigo de forma universal y que cualquier programador interesado lo pueda revisar, utilizar o mejorar desde el GitHub habilitado para ello.
- **Apartados opcionales**: Se han implementado todas las tareas opcionales de todos los laboratorios, incluído el actual.
- ** Mejoras finales** : Se detallarán mas extensamente en el apartado de conclusiones, a pesar de ello, destacamos que las diferentes mejoras han sido aplicadas en pos de la funcionalidad y/o de la eficiencia.
- **Pagina web 100% funcional**: Desde el momento de la entrega de este documento, el repositorio de GitHub que contiene este proyecto pasará de privado a público poniendo a disposición de quien lo requiera todo el código. Así mismo, disponemos de la página web donde se detallan todos los cambios y el funcionamiento del programa.

**Hemos definido que el programa cumpla** las siguientes funciones:

1. *** Carga de datos desde fichero:* ** Se dará a elegir al usuario si quiere cargar la lista completa o solo querrá cargar los actores/peliculas que se encuentren bien escritos, es decir, que sean legibles tras haber sido tratados con un método que hemos establecido para normalizar nombres en base a caracteres desconocidos.
2. *** Búsqueda de un actor/película:* ** Devolverá el actor en caso de existir, en caso contrario dará un aviso por terminal/pop-up.
3. *** Inserción de un actor/película:* ** Indica si ha sido posible añadir el actor o si el mismo existía previamente.
4. *** Eliminación de un actor/película:* ** Indica si el actor existe y en ese caso, que ha sido borrado. En caso contrario informará de que no existe.
5. *** Obtener la lista de peliculas de un actor:* * ** Comprueba que el actor exista, y en caso positivo, muestra la lista de peliculas del mismo
6. *** Obtener la lista de actores de una pelicula (reparto):* **  Comprobamos que la pelicula existe previamente y en caso positivo, imprimimos por pantalla los actores que la componen. En caso de no existir, se informará de dicha situación al usuario.
7. *** Modificar el presupuesto de una pelicula:* ** Comprobamos que la pelicula introducida existe previamente y si es así, incrementamos el valor de recaudación en X (donde X es el valor introducido por el usuario). En caso de no existir la pelicula, se informará de dicha siatuación al usuario.
8. *** Obtener una lista de actores ordenada (nombre, apellido):* ** Obtenemos una lista de actores ordenados bajo el criterio: Nombre Apellido (separados unicamente por un espacio)
9. *** Exportar los datos a un fichero de texto:* ** Exportamos la lista ordenada de los actores, con sus respetivas peliculas a un fichero de texto `.txt`
10. *** EstanConectados * ** : Este método se encargará de analizar la lista completa de actores y todas sus peliculas y encontrar una relación entre ambos. La idea final es que dados dos nombres de películas sea capaz de imprimir si ambas estan relacionadas por una sucesión de peliculas y los actores que las protagonicen entre si.
11. *** Page Rank * **: Éste método se encarga de calcular el PageRank de la forma en que se indicaba en la documentación. Adicionalmente hemos implementado la parte opcional y en la misma, damos al usuario dos opciones; la primera, el usuario puede crear su propia lista de peliculas a valorar (se comprueba que las peliculas existan, también que no se añadan de forma repetida) o, la segunda, se ha implementado un algoritmo que calcula de forma aleatoria actores que tengan mas de 3 peliculas en su filmografia y permite calcular sus Page Rank.


* * *

## 2. Diagrama de clases

Este es el diseño final del programa, los diseños iniciales y la evolución de los mismos hasta llegar a esta se encuentran en nuestro GitHub.

![](/Users/Josu/Desktop/diagram4.png)


* * *

## 3. Descripción de las estructuras de datos principales

Como comentábamos en la introducción del documento, **la parte más importante** del documento recae en los métodos que realizan **las búsquedas**. Dado que **son necesarios para trabajar la información, añadir y eliminarla**.

** Como parte nueva, se ha implementado el calculo del Page Rank**. Para ello, se ha utilizado como base la estructura que se creó en el anterior laboratorio, el grafo. Por ello, reiteramos la importancia del grafo que **se ha incluido un grafo como estructura de datos**. Para poder rellenar dicho grafo, previamente se han definido tres estructuras; las indicadas en el apartado *b* de este proyecto en el libro *Algorithms*. Dichas estructuras estan conformadas por un **HashMap< String, Integer > **(los Strings serán nombres de actores/peliculas), **dicho HashMap construido de forma inversa será la estructura intermedia Array< Integer > y el resultado sera un grafo (ArrayList< Integer >[])**. Para ello, hemos volcado la forma de trabajo de dicha estructura final en una **clase *Graph* que servirá de API para futuros proyectos relacionados. Así mismo hemos construido otra clase genérica** (basandonos en los apuntes del libro) **que servirá de nuevo como futura API, la clase *Graph*. Finalmente, el *SymbolGraph* **(que será la estructura de actores/peliculas) **será la estructura del grafo, que a su vez que basara en dos clases que hemos generado para el proceso de estanConectados *BreathFirstSearch* y *DegreesOfSeparation* **.

Para trabajar las búsquedas **inicialmente lo hacíamos mediante búsquedas lineales**, pero viendo que **el coste del mismo se disparaba al trabajar con grandes cantidades de datos**; **decidimos optar por usar el algoritmo de búsqueda binaria** (que solo funciona si la lista esta previamente ordenada). La **búsqueda lineal tenía un coste de *O(n)* mientras que la dicotómica/binaria *O(log n)* **.
**Finalmente, vimos que podriamos tratar las búsquedas casi como un coste constante** si utilizabamos alguna estructura de datos de la familia **'Map'**. Por eso, replanteamos el diseño del programa e **hicimos que todas las estructuras de datos con las que trabajamos sean *HashMap < String, T >* ** donde 'T' es cualquier objeto que necesitemos almacenar (peliculas, actores...).

Teniendo en cuenta que:
- **n** es el numero de peliculas que hay en el fichero
- **m** es el numero de actores que por pelicula del fichero (n)

**Utilizando HashMap como estructura** de datos contenedora, el proceso de **cargar el fichero tiene un coste de *O(n*m)* **.Por un lado recorremos completamente el fichero de datos y por otro, tenemos que recorrer completamente la lista que estamos creando e inicializando con los datos del fichero. Al hacerlo mediante un hashmap, nos ahorramos la variable ‘p’ en el coste, dado que no tenemos que recorrer la listaAux (por que es un hashmap).

Como **algoritmo de ordenación**, utilizábamos BubbleSort. Este, habia sido el algoritmo con el que mas habíamos trabajo y con el que mas cómodos nos sentiamos, pero al igual que en el anterior caso, decidimos hacer modificaciones debido a que su coste era demasiado alto para lo que buscábamos O(n2). Hicimos distintas pruebas con MergeSort, aunque **finalmente optamos como algoritmo por el QuickSort reduciendo así el coste hasta O(n* log n)**.
Para realizar **la operación de ordenación**, previamente **volcamos las claves de nuestro HashMap** (que son los nombres de los actores) **en un Array[] de String y procedemos a ordenarlo**. **Tras esto, recibiremos una lista de claves ordenadas**, que en caso de querer mostrar unicamente los nombres de los actores cumple al 100% la función y en caso de querer mostrar mas información, lo recorreremos en orden y accederemos con cada clave a la información de nuestro catálogo (HashMap).

* * *

## 4. Diseño e implementacion de los metodos principales

Este apartado lo dedicaremos a explicar el funcionamiento de los diferentes métodos principales de las clases a implementar en este laboratorio.

###4.1. PageRank

####4.1.1 calculatePR(int v)

#####4.1.1.1 Precondicion/Postcondicion
++Precondicion:++ Tendremos el indice de un vertice perteneciente al grafo.
++Postcondicion:++ Se habrá modificado el atributo PageRank del actor/pelicula al que correspondía el vértice.

#####4.1.1.2 Casos de prueba
* Existe el valor introducido como parámetro.
* El valor introducido como parámetro corresponde con alguno existente en el grafo.

#####4.1.1.3 Coste

El coste de este algoritmo será de ** *O(n x m x p)* **, donde **n** será el número de films como vertices; y **m** corresponderá a los vertices de cada **n**, que en este caso serán actores.

#####4.1.1.4 Pseudo-algoritmo

		private boolean calculatePR(int v) {
        double result = 0.0;
        para (int auxV : SymbolGraph.getMySymbolGraph().graph().adj(v)) {
            Film f;
            Actor a;
            boolean isFilm = false;
            si (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
                isFilm = true;
            }
            si (isFilm) {
                si (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    a = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int cantidadVertices = 0;
                    para (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        cantidadVertices++;
                    }
                    a.setPRRelativo(a.getpR() / cantidadVertices);
                    result += a.obtenerPRRelativo();
                }
            } sino {
                si (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    f = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int cantidadVertices = 0;
                    para (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        cantidadVertices++;
                    }
                    f.setPRRelativo(f.getpR() / cantidadVertices);
                    result += f.obtenerPRRelativo();
                }
            }
        }
                double PRTemporal = 1.0;
        si (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            PRTemporal = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).obtenerPR();
            FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).setPR(INITIALCALCULATIONVALUE + (DF * result));
            PRTemporal = abs(FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).obtenerPR() - PRTemporal);
        }
        si (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            PRTemporal = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).obtenerPR();
            ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            PRTemporal = abs(ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).obtenerPR() - PRTemporal);
        }
        return (PRTemporal < 0.00001);
    }

####4.1.1.5 Método final

```java
    private boolean calculatePR(int v) {
        double result = 0.0;
        for (int auxV : SymbolGraph.getMySymbolGraph().graph().adj(v)) {
            Film f;
            Actor a;
            boolean isFilm = false;
            if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
                isFilm = true;
            }
            if (isFilm) {
                if (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    a = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int i = 0;
                    for (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        i++;
                    }
                    a.setpRelative(a.getpR() / i);
                    result += a.getpRelative();
                }
            } else {
                if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    f = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int i = 0;
                    for (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        i++;
                    }
                    f.setpRelative(f.getpR() / i);
                    result += f.getpRelative();
                }
            }
        }
        double tempPr = 1.0;
        if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            tempPr = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR();
            FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            tempPr = abs(FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR() - tempPr);
        }
        if (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            tempPr = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR();
            ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            tempPr = abs(ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR() - tempPr);
        }
        return (tempPr < 0.00001);
    }
```
####4.1.2 calculateAllPR()

#####4.1.1.1 Precondicion/Postcondicion
++Precondicion:++ Tendremos un grafo ya generado.
++Postcondicion:++ Se habrá calculado el valor de los PageRank de cada elemento del grafo.

#####4.1.1.2 Casos de prueba
* Existe el grafo.

#####4.1.1.3 Coste

El coste de este algoritmo será ** *O(n x m x p)* **, ya que este algoritmo ejecutará el anterior, un numero indefinido de veces, hasta que se cumpla una condición. Esta cantidad de iteraciones corresponderá a la variable **p**.

#####4.1.1.4 Pseudo-algoritmo

		public void calculateAllPr() {
        System.out.println("\n\t--- Calculating all Page Ranks ---");
        int Gsize = SymbolGraph.getMySymbolGraph().graph().V();
        int i = 0;
        int porcentaje = 0;
        boolean flag = false;
        mientras (i < tamañoGrafo && !flag) {
            flag = this.calcularPR(i);
            i++;
            si (((i * 100) / tamañoGrafo) % 10 == 0) {
                if (((i * 100) / tamañoGrafo) != porcentaje) {
                    porcentaje = ((i * 100) / tamañoGrafo);
                    System.out.println("\t\t[*] " + porcentaje + "%" + " porcentaje completed");
                }
            }
            si (i == tamañoGrafo) {
                i = 0;
            }
        }
        FileManager.getMyFileManager().exportarPR();
    }

####4.1.1.5 Método final

```java
   public void calculateAllPr() {
        System.out.println("\n\t--- Calculating all Page Ranks ---");
        int Gsize = SymbolGraph.getMySymbolGraph().graph().V();
        int i = 0;
        int percentage = 0;
        boolean flag = false;
        while (i < Gsize && !flag) {
            flag = this.calculatePR(i);
            i++;
            if (((i * 100) / Gsize) % 10 == 0) {
                if (((i * 100) / Gsize) != percentage) {
                    percentage = ((i * 100) / Gsize);
                    System.out.println("\t\t[*] " + percentage + "%" + " percentage completed");
                }
            }
            if (i == Gsize) {
                i = 0;
            }
        }
        FileManager.getMyFileManager().exportPRToFile();
    }
```
####4.1.2 calculateAllPRFromFilmList(FilmList fl)

#####4.1.1.1 Precondicion/Postcondicion
++Precondicion:++ Tendremos una lista de películas.
++Postcondicion:++ Se habrá calculado el PageRank de todos los elemento del grafo, partiendo de una lista de películas.

#####4.1.1.2 Casos de prueba
* Existe la lista de películas que se introduce como parámetro.

#####4.1.1.3 Coste

El coste de este algoritmo será ** *O(n x m x p)* **, donde **n** serán los elemento en la lista de péliculas que nos entran como parámetro; **m** corresponderá a los actores de cada pélicula en la filmList; y **p** pertenecerá al número de iteraciones necesarias hasta que se de la condición de parar.

#####4.1.1.4 Pseudo-algoritmo

		public void calculateAllPrFromFimList(FilmList fl) {
        int i = 0;
        boolean flag = false;
        boolean terminado = false;
        ArrayList<String> infoRev = new ArrayList<>();
        mientras (!terminado) {
            para (String nombrePeli : fl.obtenerListaPelis().keySet()) {
                si (!flag) {
                    flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(nombrePeli));
                    String filmS = "Film--> "+nombrePeli+": "+FilmCatalog.getMyFilmCatalog().getFilm(filmName).getpR();
                    infoRev.añadir(filmS);
                    para (Actor a : FilmCatalog.getMyFilmCatalog().getFilm(filmName).getActorList().getActorL().values()){
                        flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(a.getName()+" "+a.getSurname()));
                        String actorS = "\t Actor--> "+a.getName()+" "+a.getSurname()+": "+ActorCatalog.getmyActorCatalog().searchActor(a).getpR();
                        inforRev.añadir(actorS);
                    }
                }
                i++;
            }
            terminado = (!flag && i <= fl.getSize());
        }
        FileManager.getMyFileManager().exportarPRFilmList(infoRev);
        para (String s : infoRev){
            System.out.println(s);
        }
    }

#####4.1.1.5 Método final

```java
   public void calculateAllPrFromFimList(FilmList fl) {
        int i = 0;
        boolean flag = false;
        boolean finished = false;
        ArrayList<String> calculatedInfo = new ArrayList<>();
        while (!finished) {
            for (String filmName : fl.getFilmL().keySet()) {
                if (!flag) {
                    flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(filmName));
                    String filmS = "Film--> "+filmName+": "+FilmCatalog.getMyFilmCatalog().getFilm(filmName).getpR();
                    calculatedInfo.add(filmS);
                    for (Actor a : FilmCatalog.getMyFilmCatalog().getFilm(filmName).getActorList().getActorL().values()){
                        flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(a.getName()+" "+a.getSurname()));
                        String actorS = "\t Actor--> "+a.getName()+" "+a.getSurname()+": "+ActorCatalog.getmyActorCatalog().searchActor(a).getpR();
                        calculatedInfo.add(actorS);
                    }
                }
                i++;
            }
            finished = (!flag && i <= fl.getSize());
        }
        FileManager.getMyFileManager().exportPRfromFilmListToFile(calculatedInfo);
        for (String s : calculatedInfo){
            System.out.println(s);
        }
    }
```

* * *
## 5. Código completo

- Se incluye el **diagrama de clases** completo en formato `.png`
- **Los ficheros `.java`** que contienen todos los métodos
- **Los ficheros resultado** de la carga del fichero original
	- Fichero resultado con los actores y peliculas con nombres normalizados (y descartando aquellos que tras el proceso seguian estando mal escritos)
	- Fichero resultado con todos los actores y peliculas que nuestro programa trata en la carga

### 5.1 Actor
```java
public class Actor {

    private String name;
    private String surname;
    private FilmList filmL;
    private double pR,pRelative = 0.0;


    public Actor(String pName, String pSurname) {
        this.name = pName;
        this.surname = pSurname;
        this.filmL = new FilmList();
        this.pR = 0.85;
    }

    public double getpR() {
        return pR;
    }

    public void setpR(double pR) {
        this.pR = pR;
    }

    public double getpRelative() {
        return pRelative;
    }

    public void setpRelative(double pRelative) {
        this.pRelative = pRelative;
    }

    public FilmList getFilmList() {
        return this.filmL;
    }

    public String getName() {
        return this.name;
    }

    public String getSurname() {
        return this.surname;
    }

}
```

### 5.2 ActorCatalog
```java
public class ActorCatalog {

    private static ActorCatalog myActorCatalog;
    private HashMap<String, Actor> actorL;

    private ActorCatalog() {
        this.actorL = new HashMap<>();
    }

    public static ActorCatalog getmyActorCatalog() {
        if (myActorCatalog == null) {
            myActorCatalog = new ActorCatalog();
        }
        return myActorCatalog;
    }

    public HashMap<String, Actor> getActorL() {
        return this.actorL;
    }

    private boolean exist(String pActorName, String pActorSurname) {
        return actorL.get(pActorName + " " + pActorSurname) != null;
    }

    public void addActor(Actor pActor) {
        if (!this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.put(pActor.getName() + " " + pActor.getSurname(), pActor);
        }
    }

    public Actor searchActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            return this.actorL.get(pActor.getName() + " " + pActor.getSurname());
        }
        return null;
    }

    public void removeActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.remove(pActor.getName() + " " + pActor.getSurname());
            System.out.println("Actor erased");
        } else {
            System.out.println("Actor not found");
        }
    }

    public String[] quickSortList() {
        String[] auxS = new String[actorL.size()];
        int i = 0;
        for (String key : actorL.keySet()) {
            auxS[i] = key;
            i++;
        }
        StringQuickSort.sort(auxS);
        return auxS;
    }

    public void printList(String[] auxS) {
        for (String key : auxS) {
            System.out.println(key);
        }
    }

    public float getAverageFilmsPerActor() {
        int contFilms = 0;
        for (String actorName : this.actorL.keySet()) {
            contFilms += this.actorL.get(actorName).getFilmList().getSize();
        }
        return (float) contFilms / (float) this.actorL.keySet().size();
    }
}
```
### 5.3 ActorList
```java
public class ActorList {

    private HashMap<String, Actor> actorList;


    public ActorList() {
        this.actorList = new HashMap<>();
    }

    public HashMap<String, Actor> getActorL(){return this.actorList;}


    public boolean exist(String pActorName, String pActorSurname) {
        return this.actorList.get(pActorName + " " + pActorSurname) != null;
    }

    public void addActor(Actor auxActor) {
        if (!this.exist(auxActor.getName(), auxActor.getSurname())) {
            this.actorList.put(auxActor.getName() + " " + auxActor.getSurname(), auxActor);
        }
    }

    public Actor  searchActor(Actor auxActor){
        if (this.exist(auxActor.getName(), auxActor.getSurname())){
            return this.actorList.get(auxActor.getName()+" "+auxActor.getSurname());
        }else{
            return null;
        }
    }

    public Actor getActor(String pActorName, String pActorSurname) {
        if (this.actorList.get(pActorName + " " + pActorSurname) != null) {
            return actorList.get(pActorName);
        }
        return null;
    }

    public void removeActor(Actor pActor) {
        if (this.actorList.get(pActor.getName() + " " + pActor.getSurname()) != null) {
            this.actorList.remove(pActor.getName() + " " + pActor.getSurname());
        }
    }

    public void printActors() {
        System.out.println("These are all the actors: ");
        for (HashMap.Entry<String, Actor> entry : actorList.entrySet()) {
            String key = entry.getKey();
            System.out.println(key);
        }
    }

    public int getSize(){
        return  this.actorList.size();
    }
}
```

### 5.4 Bag
```java
public class Bag<Item> implements Iterable<Item> {
    private Node<Item> first;    // beginning of bag
    private int n;               // number of elements in bag

    // helper linked list class
    private static class Node<Item> {
        private Item item;
        private Node<Item> next;
    }

    /**
     * Initializes an empty bag.
     */
    public Bag() {
        first = null;
        n = 0;
    }

    public int size() {
        return n;
    }

    public void add(Item item) {
        Node<Item> oldfirst = first;
        first = new Node<Item>();
        first.item = item;
        first.next = oldfirst;
        n++;
    }

    public Iterator<Item> iterator()  {
        return new ListIterator<>(first);
    }

    // an iterator, doesn't implement remove() since it's optional
    private class ListIterator<Item> implements Iterator<Item> {
        private Node<Item> current;

        public ListIterator(Node<Item> first) {
            current = first;
        }

        public boolean hasNext()  { return current != null;                     }
        public void remove()      { throw new UnsupportedOperationException();  }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

}
```
### 5.5 BreathFirtstPaths
```java
public class BreadthFirstPaths {
    private static final int INFINITY = Integer.MAX_VALUE;
    private boolean[] marked;  // marked[v] = is there an s-v path
    private int[] edgeTo;      // edgeTo[v] = previous edge on shortest s-v path
    private int[] distTo;      // distTo[v] = number of edges shortest s-v path

    public BreadthFirstPaths(Graph G, int s) throws InterruptedException {
        marked = new boolean[G.V()];
        distTo = new int[G.V()];
        edgeTo = new int[G.V()];
        validateVertex(s);
        bfs(G, s);

        assert check(G, s);
    }

    // breadth-first search from a single source
    private void bfs(Graph G, int s) throws InterruptedException {
        Queue<Integer> q = new Queue<>();
        for (int v = 0; v < G.V(); v++)
            distTo[v] = INFINITY;
        distTo[s] = 0;
        marked[s] = true;
        q.enqueue(s);

        while (!q.isEmpty()) {
            int v = q.dequeue();
            for (int w : G.adj(v)) {
                if (!marked[w]) {
                    edgeTo[w] = v;
                    distTo[w] = distTo[v] + 1;
                    marked[w] = true;
                    q.enqueue(w);
                }
            }
        }
    }

    public boolean hasPathTo(int v) {
        validateVertex(v);
        return marked[v];
    }
    public Iterable<Integer> pathTo(int v) {
        validateVertex(v);
        if (!hasPathTo(v)) return null;
        Stack<Integer> path = new Stack<>();
        int x;
        for (x = v; distTo[x] != 0; x = edgeTo[x])
            path.push(x);
        path.push(x);
        return path;
    }

    // check optimality conditions for single source
    private boolean check(Graph G, int s) {

        // check that the distance of s = 0
        if (distTo[s] != 0) {
            System.out.println("distance of source " + s + " to itself = " + distTo[s]);
            return false;
        }

        // check that for each edge v-w dist[w] <= dist[v] + 1
        // provided v is reachable from s
        for (int v = 0; v < G.V(); v++) {
            for (int w : G.adj(v)) {
                if (hasPathTo(v) != hasPathTo(w)) {
                    System.out.println("edge " + v + "-" + w);
                    System.out.println("hasPathTo(" + v + ") = " + hasPathTo(v));
                    System.out.println("hasPathTo(" + w + ") = " + hasPathTo(w));
                    return false;
                }
                if (hasPathTo(v) && (distTo[w] > distTo[v] + 1)) {
                    System.out.println("edge " + v + "-" + w);
                    System.out.println("distTo[" + v + "] = " + distTo[v]);
                    System.out.println("distTo[" + w + "] = " + distTo[w]);
                    return false;
                }
            }
        }

        // check that v = edgeTo[w] satisfies distTo[w] = distTo[v] + 1
        // provided v is reachable from s
        for (int w = 0; w < G.V(); w++) {
            if (!hasPathTo(w) || w == s) continue;
            int v = edgeTo[w];
            if (distTo[w] != distTo[v] + 1) {
                System.out.println("shortest path edge " + v + "-" + w);
                System.out.println("distTo[" + v + "] = " + distTo[v]);
                System.out.println("distTo[" + w + "] = " + distTo[w]);
                return false;
            }
        }

        return true;
    }

    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void validateVertex(int v) {
        int V = marked.length;
        if (v < 0 || v >= V)
            throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V-1));
    }
}
```

### 5.6 DegreesOfSeparation
```java
public class DegreesOfSeparation {

    private static DegreesOfSeparation myDegrees;

    // this class cannot be instantiated
    private DegreesOfSeparation() {
    }

    public static DegreesOfSeparation getMyDegrees(){
        if (myDegrees == null){
            myDegrees = new DegreesOfSeparation();
        }
        return myDegrees;
    }

    public void calculateDegrees(String p1, String p2) throws InterruptedException {
        Graph G = SymbolGraph.getMySymbolGraph().graph();
        if (!SymbolGraph.getMySymbolGraph().contains(p1)) {
            System.out.println(p1 + " not in database.");
        } else {
            int s = SymbolGraph.getMySymbolGraph().indexOf(p1);
            BreadthFirstPaths bfs = new BreadthFirstPaths(G, s);
            if (SymbolGraph.getMySymbolGraph().contains(p2)) {
                int t = SymbolGraph.getMySymbolGraph().indexOf(p2);
                if (bfs.hasPathTo(t)) {
                    for (int v : bfs.pathTo(t)) {
                        System.out.println("   " + SymbolGraph.getMySymbolGraph().nameOf(v));
                    }
                } else {
                    System.out.println("Not connected");
                }
            } else {
                System.out.println("   Not in database.");
            }
        }
    }
}
```

### 5.7 EDA1617
```java
public class EDA1516 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, InterruptedException {

        Object[] options = {"GUI based", "Console based"};

        //int n = JOptionPane.showOptionDialog(null,"Choose what launcher do you want to use", "EDA16-17 Selection Menu",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[1])

        System.out.println("\t\t***** Welcome to EDA16/17 project *****\n");

        System.out.println("\tSelect (1) for gui based program launch (still in development, less customizable)");
        System.out.println("\tSelect (2) for terminal based program launch (finished and more customizable experience");

        int n = Keyboard.getMyKeyboard().getInt();

        if (n == 1) {

            JFrame frame = SwingGUI.getMyJMenu();

            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();         //En dim guardamos el tamaño de la pantalla donde se esta ejecutando el programa

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //fijamos que la operacion por defecto al cerrar es salir
            frame.pack();
            frame.isAlwaysOnTop();
            frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);         //Fijamos por defecto que la ventana siempre aparezca en el centro
            frame.setVisible(true); //hacemos el frame visible
            frame.setResizable(false);
        } else {
            TerminalUI.main();
        }
    }
}
```
### 5.8 FileManager
```java
public class EDA1516 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, InterruptedException {

        Object[] options = {"GUI based", "Console based"};

        //int n = JOptionPane.showOptionDialog(null,"Choose what launcher do you want to use", "EDA16-17 Selection Menu",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[1])

        System.out.println("\t\t***** Welcome to EDA16/17 project *****\n");

        System.out.println("\tSelect (1) for gui based program launch (still in development, less customizable)");
        System.out.println("\tSelect (2) for terminal based program launch (finished and more customizable experience");

        int n = Keyboard.getMyKeyboard().getInt();

        if (n == 1) {

            JFrame frame = SwingGUI.getMyJMenu();

            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();         //En dim guardamos el tamaño de la pantalla donde se esta ejecutando el programa

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //fijamos que la operacion por defecto al cerrar es salir
            frame.pack();
            frame.isAlwaysOnTop();
            frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);         //Fijamos por defecto que la ventana siempre aparezca en el centro
            frame.setVisible(true); //hacemos el frame visible
            frame.setResizable(false);
        } else {
            TerminalUI.main();
        }
    }
}
```
### 5.9 Film
```java
public class Film {

    private String name;
    private int earned = 0;
    private ActorList actorList;
    private double pR, pRelative = 0.0;
    private ArrayList<Film> friends = new ArrayList<>();

    public Film(String pName) {
        this.name = pName;
        this.actorList = new ActorList();
        this.pR = 0.85;
    }

    public double getpR() {
        return pR;
    }

    public void setpR(double pR) {
        this.pR = pR;
    }

    public double getpRelative() {
        return pRelative;
    }

    public void setpRelative(double pRelative) {
        this.pRelative = pRelative;
    }

    public ArrayList<Film> getFriends() { return this.friends;}

    public String getName() {
        return this.name;
    }

    public int getEarned() {
        return this.earned;
    }

    public void incrementEarned(int auxEarned) {
        this.earned += auxEarned;
    }

    public ActorList getActorList() {
        return this.actorList;
    }
}
```
### 5.10 FilmCatalog
```java
public class FilmCatalog {

    private static FilmCatalog myFilmCatalog;
    private HashMap<String, Film> filmL;

    private FilmCatalog() {
        this.filmL = new HashMap<>();
    }

    public static FilmCatalog getMyFilmCatalog() {
        if (myFilmCatalog == null) {
            myFilmCatalog = new FilmCatalog();
        }
        return myFilmCatalog;
    }

    public boolean exist(String pFilmName) {
        return filmL.get(pFilmName) != null;
    }

    public void addFilm(Film pFilm) {
        if (!this.exist(pFilm.getName())) {
            this.filmL.put(pFilm.getName(), pFilm);
        }
    }

    public Film getFilm(String pFilmName) {
        if (this.exist(pFilmName)) {
            return this.filmL.get(pFilmName);
        }
        return null;
    }

    public int getSize(){
        return this.filmL.size();
    }

    public HashMap<String, Film> getFilmL() { return this.filmL;}

    public float getAverageActorsPerFilm(){
        int contActors = 0;
        for (String filmName : this.filmL.keySet()){
            contActors += this.filmL.get(filmName).getActorList().getSize();
        }
        return (float)contActors/(float)this.filmL.keySet().size();
    }

}
```
### 5.11 FilmList
```java
public class FilmList {

    private HashMap<String, Film> filmL;

    public FilmList() {
        this.filmL = new HashMap<>();
    }


    private boolean exist(String pFilmName) {
        return this.filmL.get(pFilmName) != null;
    }

    public void addFilm(Film pFilm) {
        if (!this.exist(pFilm.getName())) {
            this.filmL.put(pFilm.getName(), pFilm);
        }
    }

    public Film getFilm(String pFilmName) {
        if (this.filmL.get(pFilmName) != null) {
            return this.filmL.get(pFilmName);
        }
        return null;
    }

    public HashMap<String, Film> getFilmL() {
        return this.filmL;
    }

    public void printFilms() {
        System.out.println("These are all the films: ");
        for (HashMap.Entry<String, Film> entry : filmL.entrySet()) {
            String key = entry.getKey();
            System.out.println(key.toString());
        }
    }

    public int getSize(){
        return this.filmL.size();
    }
}
```
### 5.12 Graph
```java
public class Graph {
    private static final String NEWLINE = System.getProperty("line.separator");

    private int V;
    private int E;
    private Bag<Integer>[] adj;

    public Graph(int V) {
        if (V < 0) throw new IllegalArgumentException("Number of vertices must be nonnegative");
        this.V = V;
        this.E = 0;
        adj = (Bag<Integer>[]) new Bag[V];
        for (int v = 0; v < V; v++) {
            adj[v] = new Bag<>();
        }
    }

    public int V() {
        return V;
    }

    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void validateVertex(int v) {
        if (v < 0 || v >= V)
            throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V-1));
    }

    public void addEdge(int v, int w) {
        validateVertex(v);
        validateVertex(w);
        E++;
        adj[v].add(w);
        adj[w].add(v);
    }

    public Iterable<Integer> adj(int v) {
        validateVertex(v);
        return adj[v];
    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(V + " vertices, " + E + " edges " + NEWLINE);
        for (int v = 0; v < V; v++) {
            s.append(v + ": ");
            for (int w : adj[v]) {
                s.append(w + " ");
            }
            s.append(NEWLINE);
        }
        return s.toString();
    }
}

```
### 5.13 JMenu
```java
public class JMenu extends javax.swing.JFrame {

    private static JMenu myJMenu;
    private javax.swing.JButton button1;
    private javax.swing.JButton button2;
    private javax.swing.JTextField button2textField;
    private javax.swing.JButton button3;
    private javax.swing.JTextField button3textField;
    private javax.swing.JButton button4;
    private javax.swing.JTextField button4textField;
    private javax.swing.JButton button5;
    private javax.swing.JTextField button5textField;
    private javax.swing.JButton button6;
    private javax.swing.JTextField button6textField;
    private javax.swing.JButton button7;
    private javax.swing.JTextField button7textField;
    private javax.swing.JButton button8;
    private javax.swing.JButton button9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JProgressBar jProgressBar;

    /**
     * Creates new form JMenu
     */
    public JMenu() {
        initComponents();
    }

    public static JMenu getMyJMenu() {
        if (myJMenu == null) {
            myJMenu = new JMenu();
        }
        return myJMenu;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        button1 = new javax.swing.JButton();
        button2 = new javax.swing.JButton();
        button3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        button4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        button5 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        button6 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        button7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        button8 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        button9 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jProgressBar = new javax.swing.JProgressBar();
        button2textField = new javax.swing.JTextField();
        button3textField = new javax.swing.JTextField();
        button4textField = new javax.swing.JTextField();
        button5textField = new javax.swing.JTextField();
        button6textField = new javax.swing.JTextField();
        button7textField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel1.setText("IMDb Actor/Movie Catalog - EDA16-17-  ");

        button1.setText("(1)");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        button2.setText("(2)");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });

        button3.setText("(3)");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });

        jLabel2.setText("Read data from file");

        jLabel3.setText("Search for an actor/actress");

        jLabel4.setText("Add a new actor/actress");

        button4.setText("(4)");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });

        jLabel5.setText("Search for films of a particular actor");

        button5.setText("(5)");
        button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button5ActionPerformed(evt);
            }
        });

        jLabel6.setText("Search for actors of a particular film");

        button6.setText("(6)");
        button6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button6ActionPerformed(evt);
            }
        });


        jLabel7.setText("Increase the money raised by a film");

        button7.setText("(7)");
        button7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button7ActionPerformed(evt);
            }
        });

        jLabel8.setText("Erase an actor/actress");

        button8.setText("(8)");
        button8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button8ActionPerformed(evt);
            }
        });

        jLabel9.setText("Obtain an ordered list of actors (name, surname)");

        button9.setText("(9)");
        button9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button9ActionPerformed(evt);
            }
        });

        jLabel10.setText("Save/Export the list to a file");

        button2textField.setText("Actor/Actress name to search for");

        button3textField.setText("Actor/Actress name to add");

        button4textField.setText("Name of the film");

        button5textField.setText("Name of the actor/actress");

        button6textField.setText("Amount of money to increase");
        button6textField.setVisible(false);

        button7textField.setText("Actor/Actress name to delete");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(106, 106, 106)
                                                .addComponent(jLabel1))
                                        .addGroup(layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(button9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel2)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(jProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel3)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(button2textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel4)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button3textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel5)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button4textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel6)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button5textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel7)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button6textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel8)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button7textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jLabel9)
                                                        .addComponent(jLabel10))))
                                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(button1)
                                                .addComponent(jLabel2))
                                        .addComponent(jProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button2)
                                        .addComponent(jLabel3)
                                        .addComponent(button2textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button3)
                                        .addComponent(jLabel4)
                                        .addComponent(button3textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button4)
                                        .addComponent(jLabel5)
                                        .addComponent(button4textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button5)
                                        .addComponent(jLabel6)
                                        .addComponent(button5textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button6)
                                        .addComponent(jLabel7)
                                        .addComponent(button6textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button7)
                                        .addComponent(jLabel8)
                                        .addComponent(button7textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button8)
                                        .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button9)
                                        .addComponent(jLabel10))
                                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            //URL url = getClass().getResource("test500films.txt");
            //File auxFile = new File(url.getPath().replaceAll("%20", " "));
            jProgressBar.setMinimum(0);
            jProgressBar.setMaximum(100);
            //FileReader fr = new FileReader(auxFile);
            //FileManager.getMyFileManager().readFile(fr);
            FileManager.getMyFileManager().readFile(1);
        } catch (FileNotFoundException e1) {
            System.out.println("File not found. ¿Are you sure that you're opening the correct file?");
        } catch (IOException e2) {
            System.out.println("IOException when counting lines for the progress bar");
        }

    }

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {
        String auxActorName = button2textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        Actor actor = ActorCatalog.getmyActorCatalog().searchActor(auxActor);
        if (actor != null) {
            System.out.println("Actor finded. " + actor.getName() + " " + actor.getSurname());
        } else {
            System.out.println("Actor: " + button2textField.getText() + " not found");
        }
    }

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {
        String auxActorName = button3textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        if (ActorCatalog.getmyActorCatalog().searchActor(auxActor) != null) {
            System.out.println("Actor already exists");
        } else {
            ActorCatalog.getmyActorCatalog().addActor(auxActor);
        }
    }

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {
        String auxActorName = button4textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        if (ActorCatalog.getmyActorCatalog().searchActor(auxActor) != null) {
            ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)).getFilmList().printFilms();
        } else {
            System.out.println("Not posible to erase. Actor doesn't exist");
        }

    }

    private void button5ActionPerformed(java.awt.event.ActionEvent evt) {
        String auxFilmName = button5textField.getText();
        if (FilmCatalog.getMyFilmCatalog().getFilm(auxFilmName) != null) {
            FilmCatalog.getMyFilmCatalog().getFilm(auxFilmName).getActorList().printActors();
        }
    }

    private void button6ActionPerformed(java.awt.event.ActionEvent evt) {
        JTextField filmName = new JTextField(15);
        JTextField moneyQuantity = new JTextField(15);

        JPanel myPanel = new JPanel();
        myPanel.add(new JLabel("Film name:"));
        myPanel.add(filmName);
        myPanel.add(Box.createHorizontalStrut(15)); // a spacer
        myPanel.add(new JLabel("Money quantity:"));
        myPanel.add(moneyQuantity);

        JOptionPane.showConfirmDialog(null, myPanel,
                "Please enter filmName and moneyQuantity values", JOptionPane.OK_CANCEL_OPTION);
        try {
            FilmCatalog.getMyFilmCatalog().getFilm(filmName.getText()).incrementEarned(Integer.parseInt(moneyQuantity.getText()));
            System.out.println("Total earned by the film: " + FilmCatalog.getMyFilmCatalog().getFilm(filmName.getText()).getEarned());
        } catch (NullPointerException e1) {
            System.out.println("File not found or invalid moneyQuantity");
        }
    }

    private void button7ActionPerformed(java.awt.event.ActionEvent evt) {
        String auxActorName = button7textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        try {
            ActorCatalog.getmyActorCatalog().removeActor(new Actor(auxActorName, auxActorSurname));
        } catch (NullPointerException e1) {
            System.out.println("Actor not found");
        }
    }

    private void button8ActionPerformed(java.awt.event.ActionEvent evt) {
        ActorCatalog.getmyActorCatalog().quickSortList();
    }

    private void button9ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            FileManager.getMyFileManager().exportToFile();
        } catch (Exception e1) {
            System.out.println("Error during operation");
        }
    }

    public void updateBar(int pNewValue) {
        jProgressBar.setValue(pNewValue);
    }

    /**
     * @param args the command line arguments
     */
    /*public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JMenu().setVisible(true);
            }
        });
    }*/
}

```
### 5.14 Keyboard
```java
public class Keyboard {

	private static Keyboard miKeyboard;
	private Scanner scan;
	
	public Keyboard(){
		scan = new Scanner(System.in);
	}
	
	public static Keyboard getMyKeyboard(){
		if (miKeyboard==null){
			miKeyboard = new Keyboard();
		}
		return miKeyboard;
	}

	/*
	 * Recoge un int. En caso de que no sea valido, vuelve a solicitarlo hasta que
	 * reciba un int valido.
	 */
	public int getInt(){
		String auxS = scan.nextLine();
		while(!this.isNumeric(auxS)){
			try{
				Integer.parseInt(auxS);
			}
			catch (NumberFormatException nfe){
				System.out.println("Insert a valid number");
				auxS = scan.nextLine();
			}
		}
		int resul = Integer.parseInt(auxS);
		return resul;
	}
	
	/*
	 * Comprueba si el String que se recibe es parseable a int
	 */
	private boolean isNumeric(String cadena){
		try{
			Integer.parseInt(cadena);
			return true;
		}
		catch(NumberFormatException nfe){
			return false;
		}
	}
	
	/*
	 * Recoge por Keyboard un String
	 */
	public String getString(){
		return scan.nextLine();
	}

	public int getOptionFromRange(int min, int max){
        int opt = Keyboard.getMyKeyboard().getInt();
		while (!(opt > min-1) && !(opt< max+1)){
            System.out.println("You have inserted: "+opt+".Insert a option between "+min+" and "+max);
            opt = Keyboard.getMyKeyboard().getInt();
		}
		return opt;
	}

    public boolean catchYesNo(){
        String auxS;
        auxS = scan.nextLine();
        boolean flag = false;
        if (auxS.equalsIgnoreCase("Y")){
            flag = true;
        }
        else if (auxS.equalsIgnoreCase("n")){
            flag = false;
        }
        else{
            while(!auxS.equalsIgnoreCase("y") && !auxS.equalsIgnoreCase("n")){
                System.out.println("Invalid character. Introduce Y/N");
                auxS = scan.nextLine();
            }
            if (auxS.equalsIgnoreCase("y")){
                flag = true;
            }
        }
        return flag;
    }
}
```
### 5.15 NormalizeStrings
```java
public class NormalizeStrings extends Thread {

    private static NormalizeStrings myNormalizeString;
    private HashMap<String, String> hash = new HashMap<>();

    private NormalizeStrings() {
        hash.put("Ã¡", "a");
        hash.put("Ã©", "e");
        hash.put("Ã­", "i");
        hash.put("Ã³", "o");
        hash.put("Ãº", "u");
        hash.put("Ã�", "A");
        hash.put("Ã‰", "E");
        hash.put("Ã�", "I");
        hash.put("Ã“", "O");
        hash.put("Ãš", "U");
        hash.put("Ã¤", "a");
        hash.put("Ã«", "e");
        hash.put("Ã¯", "i");
        hash.put("Ã¶", "o");
        hash.put("Ã¼", "u");
        hash.put("Ã„", "A");
        hash.put("Ã‹", "E");
        hash.put("Ã�", "I");
        hash.put("Ã–", "O");
        hash.put("Ãœ", "U");
        hash.put("Ã§", "c");
        hash.put("Ã ", "a");
        hash.put("Ã¨", "e");
        hash.put("Ã¬", "i");
        hash.put("Ã²", "o");
        hash.put("Ã¹", "u");
        hash.put("Ã€", "A");
        hash.put("Ãˆ", "E");
        hash.put("ÃŒ", "I");
        hash.put("Ã’", "O");
        hash.put("Ã™", "U");
        hash.put("Ã§", "c");
        hash.put("Ã‡", "C");
        hash.put("�", "o");
        hash.put("�", "o");
    }

    public static NormalizeStrings getMyNormalizeString() {
        if (myNormalizeString == null) {
            myNormalizeString = new NormalizeStrings();
        }
        return myNormalizeString;
    }

    public void run(String[] pLine) {
        for (String word : pLine) {
            for (String key : hash.keySet())
                if (word.contains(key)) {
                    word.replaceAll(key, hash.get(key));
                }
            this.waitXseconds(0.1);
        }

    }

    private void waitXseconds(double ms) {
        try {
            Thread.sleep((long) ms);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

}
```
### 5.16 PageRank
```java
public class PageRank {

    private final double DF = 0.85;
    private final double INITIALPR = 1 / SymbolGraph.getMySymbolGraph().graph().V();
    private final double INITIALCALCULATIONVALUE = (1 - DF) / SymbolGraph.getMySymbolGraph().graph().V();

    private static PageRank myPageRank;
    private double[] prList = new double[SymbolGraph.getMySymbolGraph().graph().V()];

    private PageRank() {
        for (int i = 0; i < prList.length - 1; i++) {
            prList[i] = INITIALPR;
        }
    }

    public static PageRank getMyPageRank() {
        if (myPageRank == null) {
            myPageRank = new PageRank();
        }
        return myPageRank;
    }

    private boolean calculatePR(int v) {
        double result = 0.0;
        for (int auxV : SymbolGraph.getMySymbolGraph().graph().adj(v)) {
            Film f;
            Actor a;
            boolean isFilm = false;
            if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
                isFilm = true;
            }
            if (isFilm) {
                if (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    a = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int i = 0;
                    for (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        i++;
                    }
                    a.setpRelative(a.getpR() / i);
                    result += a.getpRelative();
                }
            } else {
                if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    f = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int i = 0;
                    for (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        i++;
                    }
                    f.setpRelative(f.getpR() / i);
                    result += f.getpRelative();
                }
            }
        }
        double tempPr = 1.0;
        if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            tempPr = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR();
            FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            tempPr = abs(FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR() - tempPr);
        }
        if (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            tempPr = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR();
            ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            tempPr = abs(ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR() - tempPr);
        }
        return (tempPr < 0.00001);
    }

    public void calculateAllPr() {
        System.out.println("\n\t--- Calculating all Page Ranks ---");
        int Gsize = SymbolGraph.getMySymbolGraph().graph().V();
        int i = 0;
        int percentage = 0;
        boolean flag = false;
        while (i < Gsize && !flag) {
            flag = this.calculatePR(i);
            i++;
            if (((i * 100) / Gsize) % 10 == 0) {
                if (((i * 100) / Gsize) != percentage) {
                    percentage = ((i * 100) / Gsize);
                    System.out.println("\t\t[*] " + percentage + "%" + " percentage completed");
                }
            }
            if (i == Gsize) {
                i = 0;
            }
        }
        FileManager.getMyFileManager().exportPRToFile();
    }

    public void calculateAllPrFromFimList(FilmList fl) {
        int i = 0;
        boolean flag = false;
        boolean finished = false;
        ArrayList<String> calculatedInfo = new ArrayList<>();
        while (!finished) {
            for (String filmName : fl.getFilmL().keySet()) {
                if (!flag) {
                    flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(filmName));
                    String filmS = "Film--> "+filmName+": "+FilmCatalog.getMyFilmCatalog().getFilm(filmName).getpR();
                    calculatedInfo.add(filmS);
                    for (Actor a : FilmCatalog.getMyFilmCatalog().getFilm(filmName).getActorList().getActorL().values()){
                        flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(a.getName()+" "+a.getSurname()));
                        String actorS = "\t Actor--> "+a.getName()+" "+a.getSurname()+": "+ActorCatalog.getmyActorCatalog().searchActor(a).getpR();
                        calculatedInfo.add(actorS);
                    }
                }
                i++;
            }
            finished = (!flag && i <= fl.getSize());
        }
        FileManager.getMyFileManager().exportPRfromFilmListToFile(calculatedInfo);
        for (String s : calculatedInfo){
            System.out.println(s);
        }
    }
}
```
### 5.17 StringQuickSort
```java
public class StringQuickSort {

    public static void sort(String[] array) {
        sort(array, 0, array.length);
    }

    private static void sort(String[] array, int fromIndex, int toIndex) {
        if (toIndex - fromIndex < 2) {
            return;
        }
        long timeStart = System.currentTimeMillis();
        sortImpl(array, fromIndex, toIndex, 0);
        long timeTotal = (System.currentTimeMillis() - timeStart);
        System.out.println("\t\t --- Elapsed time to order the actor list --- : " + (int) timeTotal / 1000 + "sec, " + timeTotal * 1000 + "ms\n");
    }

    private static void sortImpl(String[] array, int fromIndex, int toIndex, int stringLength) throws NullPointerException {

        int rangeLength = toIndex - fromIndex;

        if (rangeLength < 2) {
            return;
        }

        int finger = fromIndex;

        // Put all strings of length 'stringLength' to the beginning of the
        // requested sort range.
        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];
            if (current.length() == stringLength) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        fromIndex = finger;

        // Choose a pivot string by median.
        String probeLeft = array[fromIndex];
        String probeRight = array[toIndex - 1];
        String probeMiddle = array[fromIndex + rangeLength >> 1];

        String pivot = median(probeLeft, probeMiddle, probeRight);

        // Process strings S for which S[stringLength] < X[stringLength].
        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];

            if (current.charAt(stringLength) < pivot.charAt(stringLength)) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        sortImpl(array, fromIndex, finger, stringLength);

        fromIndex = finger;

        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];

            if (current.charAt(stringLength) == pivot.charAt(stringLength)) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        sortImpl(array, fromIndex, finger, stringLength + 1);
        sortImpl(array, finger, toIndex, stringLength);
    }

    private static String median(String a, String b, String c) {
        if (a.compareTo(b) <= 0) {
            if (c.compareTo(a) <= 0) {
                return a;
            }
            return b.compareTo(c) <= 0 ? b : c;
        }

        if (c.compareTo(b) <= 0) {
            return b;
        }
        return a.compareTo(c) <= 0 ? a : c;
    }
}
```
### 5.18 SwingGUI
```java
public class SwingGUI extends JFrame {

    private static SwingGUI myJMenu;
    private JButton button1;
    private JButton button2;
    private JTextField button2textField;
    private JButton button3;
    private JTextField button3textField;
    private JButton button4;
    private JTextField button4textField;
    private JButton button5;
    private JTextField button5textField;
    private JButton button6;
    private JTextField button6textField;
    private JButton button7;
    private JTextField button7textField;
    private JButton button8;
    private JButton button9;
    private JLabel jLabel1;
    private JLabel jLabel10;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    private JProgressBar jProgressBar;

    /**
     * Creates new form SwingGUI
     */
    public SwingGUI() {
        initComponents();
    }

    public static SwingGUI getMyJMenu() {
        if (myJMenu == null) {
            myJMenu = new SwingGUI();
        }
        return myJMenu;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    private void initComponents() {

        jLabel1 = new JLabel();
        button1 = new JButton();
        button2 = new JButton();
        button3 = new JButton();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        button4 = new JButton();
        jLabel5 = new JLabel();
        button5 = new JButton();
        jLabel6 = new JLabel();
        button6 = new JButton();
        jLabel7 = new JLabel();
        button7 = new JButton();
        jLabel8 = new JLabel();
        button8 = new JButton();
        jLabel9 = new JLabel();
        button9 = new JButton();
        jLabel10 = new JLabel();
        jProgressBar = new JProgressBar();
        button2textField = new JTextField();
        button3textField = new JTextField();
        button4textField = new JTextField();
        button5textField = new JTextField();
        button6textField = new JTextField();
        button7textField = new JTextField();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel1.setText("IMDb Actor/Movie Catalog - EDA16-17-  ");

        button1.setText("(1)");
        button1.addActionListener(evt -> button1ActionPerformed());

        button2.setText("(2)");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed();
            }
        });

        button3.setText("(3)");
        button3.addActionListener(evt -> button3ActionPerformed());

        jLabel2.setText("Read data from file");

        jLabel3.setText("Search for an actor/actress");

        jLabel4.setText("Add a new actor/actress");

        button4.setText("(4)");
        button4.addActionListener(evt -> button4ActionPerformed());

        jLabel5.setText("Search for films of a particular actor");

        button5.setText("(5)");
        button5.addActionListener(evt -> button5ActionPerformed());

        jLabel6.setText("Search for actors of a particular film");

        button6.setText("(6)");
        button6.addActionListener(evt -> button6ActionPerformed());


        jLabel7.setText("Increase the money raised by a film");

        button7.setText("(7)");
        button7.addActionListener(evt -> button7ActionPerformed());

        jLabel8.setText("Erase an actor/actress");

        button8.setText("(8)");
        button8.addActionListener(evt -> button8ActionPerformed());

        jLabel9.setText("Obtain an ordered list of actors (name, surname)");

        button9.setText("(9)");
        button9.addActionListener(evt -> button9ActionPerformed());

        jLabel10.setText("Save/Export the list to a file");

        button2textField.setText("Actor/Actress name to search for");

        button3textField.setText("Actor/Actress name to add");

        button4textField.setText("Name of the film");

        button5textField.setText("Name of the actor/actress");

        button6textField.setText("Amount of money to increase");
        button6textField.setVisible(false);

        button7textField.setText("Actor/Actress name to delete");

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(106, 106, 106)
                                                .addComponent(jLabel1))
                                        .addGroup(layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(button9, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button8, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button7, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button6, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button5, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button4, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button3, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button2, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button1, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel2)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(jProgressBar, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel3)
                                                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(button2textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel4)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button3textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel5)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button4textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel6)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button5textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel7)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button6textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel8)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button7textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jLabel9)
                                                        .addComponent(jLabel10))))
                                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                .addComponent(button1)
                                                .addComponent(jLabel2))
                                        .addComponent(jProgressBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button2)
                                        .addComponent(jLabel3)
                                        .addComponent(button2textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button3)
                                        .addComponent(jLabel4)
                                        .addComponent(button3textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button4)
                                        .addComponent(jLabel5)
                                        .addComponent(button4textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button5)
                                        .addComponent(jLabel6)
                                        .addComponent(button5textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button6)
                                        .addComponent(jLabel7)
                                        .addComponent(button6textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button7)
                                        .addComponent(jLabel8)
                                        .addComponent(button7textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button8)
                                        .addComponent(jLabel9))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(button9)
                                        .addComponent(jLabel10))
                                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }

    private void button1ActionPerformed( ) {
        try {
            jProgressBar.setMinimum(0);
            jProgressBar.setMaximum(100);
            FileManager.getMyFileManager().readFile(1);
        } catch (FileNotFoundException e1) {
            System.out.println("File not found. ¿Are you sure that you're opening the correct file?");
        } catch (IOException e2) {
            System.out.println("IOException when counting lines for the progress bar");
        }

    }

    private void button2ActionPerformed() {
        String auxActorName = button2textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        Actor actor = ActorCatalog.getmyActorCatalog().searchActor(auxActor);
        if (actor != null) {
            System.out.println("Actor finded. " + actor.getName() + " " + actor.getSurname());
        } else {
            System.out.println("Actor: " + button2textField.getText() + " not found");
        }
    }

    private void button3ActionPerformed() {
        String auxActorName = button3textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        if (ActorCatalog.getmyActorCatalog().searchActor(auxActor) != null) {
            System.out.println("Actor already exists");
        } else {
            ActorCatalog.getmyActorCatalog().addActor(auxActor);
        }
    }

    private void button4ActionPerformed() {
        String auxActorName = button4textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        if (ActorCatalog.getmyActorCatalog().searchActor(auxActor) != null) {
            ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)).getFilmList().printFilms();
        } else {
            System.out.println("Not posible to erase. Actor doesn't exist");
        }

    }

    private void button5ActionPerformed() {
        String auxFilmName = button5textField.getText();
        if (FilmCatalog.getMyFilmCatalog().getFilm(auxFilmName) != null) {
            FilmCatalog.getMyFilmCatalog().getFilm(auxFilmName).getActorList().printActors();
        }
    }

    private void button6ActionPerformed() {
        JTextField filmName = new JTextField(15);
        JTextField moneyQuantity = new JTextField(15);

        JPanel myPanel = new JPanel();
        myPanel.add(new JLabel("Film name:"));
        myPanel.add(filmName);
        myPanel.add(Box.createHorizontalStrut(15)); // a spacer
        myPanel.add(new JLabel("Money quantity:"));
        myPanel.add(moneyQuantity);

        JOptionPane.showConfirmDialog(null, myPanel,
                "Please enter filmName and moneyQuantity values", JOptionPane.OK_CANCEL_OPTION);
        try {
            FilmCatalog.getMyFilmCatalog().getFilm(filmName.getText()).incrementEarned(Integer.parseInt(moneyQuantity.getText()));
            System.out.println("Total earned by the film: " + FilmCatalog.getMyFilmCatalog().getFilm(filmName.getText()).getEarned());
        } catch (NullPointerException e1) {
            System.out.println("File not found or invalid moneyQuantity");
        }
    }

    private void button7ActionPerformed() {
        String auxActorName = button7textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        try {
            ActorCatalog.getmyActorCatalog().removeActor(new Actor(auxActorName, auxActorSurname));
        } catch (NullPointerException e1) {
            System.out.println("Actor not found");
        }
    }

    private void button8ActionPerformed() {
        ActorCatalog.getmyActorCatalog().quickSortList();
    }

    private void button9ActionPerformed() {
        try {
            FileManager.getMyFileManager().exportToFile();
        } catch (Exception e1) {
            System.out.println("Error during operation");
        }
    }

    public void updateBar(int pNewValue) {
        jProgressBar.setValue(pNewValue);
    }

```

### 5.19 SymbolGraph
```java
public class SymbolGraph {
    private HashMap<String, Integer> st;  // string -> index
    private String[] keys;           // index  -> string
    private Graph graph;             // the underlying graph
    private String graphToString;

    private static SymbolGraph mySymbolGraph;


    private SymbolGraph() {
        System.out.println("\t\t\n -- Start generating graph --- ");
        if (mySymbolGraph == null){
            // Paso 1: llenar st
            st = new HashMap<>();
            int i = 0;
            for (String f : FilmCatalog.getMyFilmCatalog().getFilmL().keySet()) {
                if (!st.containsKey(f)) {
                    st.put(f, i);
                    i++;
                }
            }
            for (String a : ActorCatalog.getmyActorCatalog().getActorL().keySet()) {
                if (!st.containsKey(a)) {
                    st.put(a, i);
                    i++;
                }
            }

            // Paso 2: llenar keys�
            keys = new String[st.size()];
            for (String k : st.keySet()) {
                keys[st.get(k)] = k;
            }

            // second pass builds the graph by connecting first vertex on each
            // line to all others
            graph = new Graph(st.size());
            int cont = 0;
            int percentage = 0;
            for (String index : st.keySet()) {
                ArrayList<String> a = new ArrayList<>();
                a.add(index);
                if (FilmCatalog.getMyFilmCatalog().getFilm(index) != null) {
                    for (String actor : FilmCatalog.getMyFilmCatalog().getFilm(index).getActorList().getActorL().keySet()) {
                        a.add(actor);
                    }
                    int v = st.get(a.get(0));
                    for (int j = 1; j < a.size(); j++) {
                        if (st.get(a.get(j)) != null) {
                            int w = st.get(a.get(j));
                            graph.addEdge(v, w);
                            cont++;
                            if (((cont * 100) / st.size()/2) % 10 == 0) {
                                if (((cont * 100) / st.size()/2) != percentage) {
                                    percentage = ((cont * 100) / st.size()/2);
                                    System.out.println("\t\t[*] " + percentage + "%" + " percentage completed");
                                }
                            }
                        }
                    }
                }
            }
            System.out.println("Graph succesfully generated. Do you want to save it to a String and print it? (Y/N) (Only for PCs with more than the usual Java heap space");
            if (Keyboard.getMyKeyboard().getString().equalsIgnoreCase("Y")) {
                this.graphToString = graph.toString();
                System.out.println(graphToString);
            }
        }
    }

    public String getGraphToString(){
        return this.graphToString;
    }

    public static SymbolGraph getMySymbolGraph(){
        if (mySymbolGraph == null){
            long time = System.currentTimeMillis();
            mySymbolGraph = new SymbolGraph();
            System.out.println(((time-System.currentTimeMillis())/1000)+"s elapsed to generate graph\n"+"****************************************************");
        }
        return mySymbolGraph;
    }

    public boolean contains(String s) {
        return st.get(s) != null;
    }

    public int indexOf(String s) {
        return st.get(s);
    }

    public String nameOf(int v) {
        validateVertex(v);
        return keys[v];
    }

    public Graph graph() {
        return graph;
    }

    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void validateVertex(int v) {
        int V = graph.V();
        if (v < 0 || v >= V)
            throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
    }
}
```
### 5.20 Degrees Of Separation
```java
public class DegreesOfSeparation {

    private static DegreesOfSeparation myDegrees;

    // this class cannot be instantiated
    private DegreesOfSeparation() {
    }

    public static DegreesOfSeparation getMyDegrees(){
        if (myDegrees == null){
            myDegrees = new DegreesOfSeparation();
        }
        return myDegrees;
    }

    public void calculateDegrees(String p1, String p2) throws InterruptedException {
        Graph G = SymbolGraph.getMySymbolGraph().graph();
        if (!SymbolGraph.getMySymbolGraph().contains(p1)) {
            System.out.println(p1 + " not in database.");
        } else {
            int s = SymbolGraph.getMySymbolGraph().indexOf(p1);
            BreadthFirstPaths bfs = new BreadthFirstPaths(G, s);
            if (SymbolGraph.getMySymbolGraph().contains(p2)) {
                int t = SymbolGraph.getMySymbolGraph().indexOf(p2);
                if (bfs.hasPathTo(t)) {
                    for (int v : bfs.pathTo(t)) {
                        System.out.println("   " + SymbolGraph.getMySymbolGraph().nameOf(v));
                    }
                } else {
                    System.out.println("Not connected");
                }
            } else {
                System.out.println("   Not in database.");
            }
        }
    }
}
```
### 5.21 TerminalUI
```java
package lab4;

import java.util.ArrayList;

import static java.lang.Math.abs;

/**
 * Created by Josu on 11/01/2017 for the project EDA16-17
 */
public class PageRank {

    private final double DF = 0.85;
    private final double INITIALPR = 1 / SymbolGraph.getMySymbolGraph().graph().V();
    private final double INITIALCALCULATIONVALUE = (1 - DF) / SymbolGraph.getMySymbolGraph().graph().V();

    private static PageRank myPageRank;
    private double[] prList = new double[SymbolGraph.getMySymbolGraph().graph().V()];

    private PageRank() {
        for (int i = 0; i < prList.length - 1; i++) {
            prList[i] = INITIALPR;
        }
    }

    public static PageRank getMyPageRank() {
        if (myPageRank == null) {
            myPageRank = new PageRank();
        }
        return myPageRank;
    }

    private boolean calculatePR(int v) {
        double result = 0.0;
        for (int auxV : SymbolGraph.getMySymbolGraph().graph().adj(v)) {
            Film f;
            Actor a;
            boolean isFilm = false;
            if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
                isFilm = true;
            }
            if (isFilm) {
                if (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    a = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int i = 0;
                    for (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        i++;
                    }
                    a.setpRelative(a.getpR() / i);
                    result += a.getpRelative();
                }
            } else {
                if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV)) != null) {
                    f = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(auxV));
                    int i = 0;
                    for (Integer value : SymbolGraph.getMySymbolGraph().graph().adj(auxV)) {
                        i++;
                    }
                    f.setpRelative(f.getpR() / i);
                    result += f.getpRelative();
                }
            }
        }
        double tempPr = 1.0;
        if (FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            tempPr = FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR();
            FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            tempPr = abs(FilmCatalog.getMyFilmCatalog().getFilm(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR() - tempPr);
        }
        if (ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)) != null) {
            tempPr = ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR();
            ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).setpR(INITIALCALCULATIONVALUE + (DF * result));
            tempPr = abs(ActorCatalog.getmyActorCatalog().getActorL().get(SymbolGraph.getMySymbolGraph().nameOf(v)).getpR() - tempPr);
        }
        return (tempPr < 0.00001);
    }

    public void calculateAllPr() {
        System.out.println("\n\t--- Calculating all Page Ranks ---");
        int Gsize = SymbolGraph.getMySymbolGraph().graph().V();
        int i = 0;
        int percentage = 0;
        boolean flag = false;
        while (i < Gsize && !flag) {
            flag = this.calculatePR(i);
            i++;
            if (((i * 100) / Gsize) % 10 == 0) {
                if (((i * 100) / Gsize) != percentage) {
                    percentage = ((i * 100) / Gsize);
                    System.out.println("\t\t[*] " + percentage + "%" + " percentage completed");
                }
            }
            if (i == Gsize) {
                i = 0;
            }
        }
        FileManager.getMyFileManager().exportPRToFile();
    }

    public void calculateAllPrFromFimList(FilmList fl) {
        int i = 0;
        boolean flag = false;
        boolean finished = false;
        ArrayList<String> calculatedInfo = new ArrayList<>();
        while (!finished) {
            for (String filmName : fl.getFilmL().keySet()) {
                if (!flag) {
                    flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(filmName));
                    String filmS = "Film--> "+filmName+": "+FilmCatalog.getMyFilmCatalog().getFilm(filmName).getpR();
                    calculatedInfo.add(filmS);
                    for (Actor a : FilmCatalog.getMyFilmCatalog().getFilm(filmName).getActorList().getActorL().values()){
                        flag = this.calculatePR(SymbolGraph.getMySymbolGraph().indexOf(a.getName()+" "+a.getSurname()));
                        String actorS = "\t Actor--> "+a.getName()+" "+a.getSurname()+": "+ActorCatalog.getmyActorCatalog().searchActor(a).getpR();
                        calculatedInfo.add(actorS);
                    }
                }
                i++;
            }
            finished = (!flag && i <= fl.getSize());
        }
        FileManager.getMyFileManager().exportPRfromFilmListToFile(calculatedInfo);
        for (String s : calculatedInfo){
            System.out.println(s);
        }
    }
}
```

* * *

## 6. Resultados de las pruebas

**Estos son los resultados de las pruebas**, en la etapa final de desarrollo (lo que estamos entregando) de la actividad. **Todos los tiempos que mostramos son medias** realizadas (entre 5-10 ejecuciones) **de la misma operación**. Las pruebas **se han realizado en diferentes equipos con diferentes sistemas operativos**, detallamos:

En el fichero normalizado encontramos **1 061 522** actores, **230 369** peliculas.
En el fichero sin normalizar (cogiento toda la informacion, independientemente de si estan bien escritos) encontramos **1 191 316** actores, **238 809** peliculas.

- **CPU**: Intel i5 6600K 3,9 GHz x 4 cores, **GPU:** nVidia GTX 970 4GB Strix,**RAM:** 16GB DDR5  2666, **SO:** *Windows 10 Pro x64*
	- Cargar fichero normalizado: 11sec
	- Cargar fichero completo: 11sec
	- Ordenar lista normalizada de actores: 0sec, 609000ms
	- Ordenar lista completa de actores: 0sec, 688000ms
	- Exportar lista normalizada de actores: 1sec, 1282000ms
	- Exportar lista completa de actores: 1sec, 1672000ms
	- Generar el grafo de conexiones entre actores y peliculas: 8sec, 809000ms
	- Búsqueda de relaciones entre dos películas: 7sec de media
	- Calcular Page Rank de todo el conjunto de datos: 450s de media
	- Calcular el PageRank de una lista de películas: 22s de media

- **CPU**: Intel i5 2,7 GHz x 2 cores, **GPU:** HD 6100,**RAM:** 8GB LPDDR3  1866, **SO:** *Mac OS Sierra (10.12)*
	- Cargar fichero normalizado: 20sec
	- Cargar fichero completo: 26sec
	- Ordenar lista normalizada de actores: 1sec, 1398000ms
	- Ordenar lista completa de actores: 1sec, 1376000ms
	- Exportar lista normalizada de actores: 12sec, 12976000ms
	- Exportar lista completa de actores: 21sec, 21158000ms
	- Generar el grafo de conexiones entre actores y peliculas: 12sec, 1206970ms
	- Búsqueda de relaciones entre dos películas: 11sec de media
	- Calcular Page Rank de todo el conjunto de datos: 6320s de media
	- Calcular el PageRank de una lista de películas: 34s de media

- **CPU**: Intel Atom Z3775 1,46 GHz x 2 cores, **GPU:** Intel HD Graphics (Bay Trail) (311 - 778 MHz),**RAM:** 2GB RAM 1333, **SO:** *Windows 10 Home x32*
	- Cargar fichero normalizado: 90sec
	- Cargar fichero completo: El ordenador no es capaz de leerlo
	- Ordenar lista normalizada de actores: 2sec, 2312000ms
	- Ordenar lista completa de actores: No es capaz de leer el fichero completo
	- Exportar lista normalizada de actores: 78sec, 78051000ms
	- Exportar lista completa de actores: No es posible leer el fichero completo
	- Generar el grafo de conexiones entre actores y peliculas: No es posible leer el fichero completo
	- Búsqueda de relaciones entre dos películas: No es posible leer el fichero completo
	- Calcular Page Rank de todo el conjunto de datos: No es posible llevar a cabo la prueba
	- Calcular el PageRank de una lista de películas: No es posible llevar a cabo la prueba

## 7. Conclusiones

**Comenzaremos destacando las novedades de esta nueva actividad**. Se ha implementado la clase Page Rank para la nueva actividad y así mismo, se han desarrollado distintas mejoras, siendo estas:

- Todas las operaciones que requieran de espera por parte del usuario están ahora controladas por información del progreso de la tarea en cuestión en fragmentos de 10% sobre un total de 100%, siendo este la finalización de la tarea en cuestión.
	- Cargar el fichero
	- Generar el grafo con toda la información
	- Calcular el Page Rank, tanto el general como el propio de una lista de Peliculas (correspondiente al apartado opcional).
	- Volcar la información en un archivo de texto: Facilitamos esta posibilidad para los siguientes casos.
		-  Guardar una lista de todo el conjunto de datos. Es decir, actores y sus peliculas. Ordenado alfabéticamente.
		-  Guardar una lista con el Page Rank total resultado de calcular tantas iteraciones como sean necesarias hasta llegar al margen anteriormente mencionado de 0.0001.
		-  Guardar una lista con el Page Rank obtenido del calculo sobre la FilmList que recibe como parametro (de nuevo, correspondiente al apartado opcional)

- Ahora, el método encargado de analizar los String del fichero durante la carga, para sustituir caracteres ilegibles funciona de forma mas eficiente al hacerlo mediante una estructura HashMap sobre la cual actuamos de la siguiente forma: la clave será el caracter que esta mal escrito(o mal reconocido por la caracterización) y el valor será el caracter por el cual hay que sustituir.

- Hemos aplicado distintas mejoras a la clase que se encarga de la interación con el usuario, entre otras, se ha añadido un metodo para generizar las selecciones de menú indicandole los valores minimos y maximos que podrá tener y devolviendo este como resultado un valor comprendido entre ambos.
- Distintas mejoras en la información que recibe el usuario sobre el proceso de cualquiera de las actividades de la aplicación
- Mejoras de usabilidad
- Mejoras de rendimiento, sustituyendo ciertas estructuras o simplificando bucles o comprobaciones que teniamos anteriormente y hemos ido viendo innecesarias.

Como recordatiorio de la anterior actividad, de las dos opciones que se dieron, **decidimos implementar** la primera de ellas (está en **una clase llamada *GraphHash*)** que realiza una búsqueda de conexiones entre películas. En segundo lugar, **hemos implementado la estructura del libro *Algorithms* **pero siguiendo sus pautas, **hemos tratado de hacer unas clases genéricas cuyos métodos sirvan de API facilmente para otros proyectos en los que haya que relacionar información**. Asi mismo, tal y como comentabamos en la introducción del documento, **hemos implementado la impresión del recorrido generado al buscar las relaciones entre las peliculas**. Adicionalmente, **tambíén es posible buscar una relación entre actores y en caso de existir, mostrar las peliculas que conforman el camino**.

Destacamos como bien hemos indicado, l**a importancia de las búsquedas en el funcionamiento de nuestro programa**. Al tener que trabajarlas tanto, es necesario optimizarlas al máximo para evitar tiempos de ejecución demasiado altos.

**Otro de los métodos con mucha importancia es cargarFichero()** dado que coge línea a línea el texto que hay en el fichero y lo trata. Es decir, elimina toda la información no relevante para el programa y añade la que si tiene importancia.
Mientras trabajamos, como ya hemos comentado, **hicimos una version del programa que trabajaba con búsquedas dicotómicas y el resultado de la experiencia fue darnos cuenta de cuanta importancia podía llegar a tener el mantener la lista ordenada** para evitar usar búsquedas lineales y que el tiempo de ejecución se volviera a disparar.

**Tras analizar el fichero y destacar un patrón que pudiera servirnos** para, basandonos en el metodo split (de la clase String), separar las lineas del documento en información que nos fuera mas sencilla de manejar; **nos centramos en optimizar al máximo el funcionamiento de esta carga**.
Para realizar la operacion de una forma mas transparente al usuario y sin saturar la ventana de la consola,** hemos desarrollado un metodo que calcula el procentaje actual del documento y la imprime por pantalla en bloques de 10% en 10%** y sin repetirse ninguna de las impresiones.
Así mismo, **hemos implementado programación basada en multiples procesos para aligerar la carga del fichero con la opción de normalización de nombres que hemos decidido aportar**. Las diferencias las detallaremos ahora con mas datos.

**Para finalizar**, remarcar que sentimos que acabamos la asignatura dejando un proyecto solido y con mucho potencial a desarrollar, por ello lo pondremos a disposición de la comunidad. De ahí, la importancia que desde un principio consideramos de mantener tanto el código como la documentación de Github en inglés.


