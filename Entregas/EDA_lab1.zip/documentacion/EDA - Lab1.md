#Practica. Actividad 1.
				UPV-EHU 2016/2017
                            
                            
                            
                Estructuras de Datos y Algoritmos
                          

              
              
                
                
                											Josu Alvarez
                                                            David Max

* * * *
##Indice

Mas informacion en la pagina web del proyecto: [GITHUB](http://txusyk.github.io/EDA16-17/): http://txusyk.github.io/EDA16-17/

[TOC]

* * *

##1. Introducción

**Dado un fichero de datos** que contiene actores y actrices de Internet Movie DataBase (IMDB), con una estructura efinida ('nombrePelicula' ---> 'nombreActor1' &&& 'nombreActor2'...) . **Se ha de implementar un programa que cargue el fichero de datos y extraiga del mismo los nombres de los actores y las peliculas que contiene**.

**El pilar del funcionamiento de nuestro programa son las búsquedas**. Dado que tanto para añadir, eliminar como para gestionar alguno de los datos previamente se hará una búsqueda para comprobar si realmente existe.

Dado que disponiamos de tiempo y que el proyecto nos ha parecido interesante, **hemos decidido implementar ciertas mejoras sobre el trabajo inicial**, siendo estas:

- ** El sistema dará la opción** al usuario para que decida como quiere ejecutar el programa, si por la **consola o bien mediante una GUI** que hemos construido con Swing.
- **Hay dos formas de cargar el archivo**, una **con todos los datos y** otra **con los datos normalizados** (se explica mejor en las proximas lineas).
- **Todo el proyecto** y todas sus versiones estan **siendo manejadas mediante GitHub**, se ha dispuesto una pagina web publica que contiene esta misma información y será actualizada con cada una de las proximas entregas.
- **Uso exclusivo de lenguaje 'Markdown' para proceder a documentar el codigo**. En nuestro esfuerzo por usar tecnologías libres y ser eficientes, hemos encontrado este lenguaje ideal (dada su total compatibilidad con las wikis y las webs de GitHub).
- **Uso del ingles** siempre que nos ha sido posible, para desarrollar el codigo de forma universal y que cualquier programador interesado lo pueda revisar, utilizar o mejorar desde el GitHub habilitado para ello.

**Hemos definido que el programa cumpla** las siguientes funciones:

1. ***Carga de datos desde fichero:* ** Se dará a elegir al usuario si quiere cargar la lista completa o solo querrá cargar los actores/peliculas que se encuentren bien escritos, es decir, que sean legibles tras haber sido tratados con un método que hemos establecido para normalizar nombres en base a caracteres desconocidos.
1. ***Búsqueda de un actor/película:* ** Devolvera el actor en caso de existir, en caso contrario dará un aviso por terminal/pop-up.
1. ***Inserción de un actor/película:* ** Indica si ha sido posible añadir el actor o si el mismo existía previamente.
1. ***Eliminación de un actor/película:* ** Indica si el actor existe y en ese caso, que ha sido borrado. En caso contrario informará de que no existe.
1. ***Obtener la lista de peliculas de un actor:* * ** Comprueba que el actor exista, y en caso positivo, muestra la lista de peliculas del mismo
1. ***Obtener la lista de actores de una pelicula (reparto):* **  Comprobamos que la pelicula existe previamente y en caso positivo, imprimimos por pantalla los actores que la componen. En caso de no existir, se informará de dicha situación al usuario.
1. ***Modificar el presupuesto de una pelicula:* ** Comprobamos que la pelicula introducida existe previamente y si es así, incrementamos el valor de recaudación en X (donde X es el valor introducido por el usuario). En caso de no existir la pelicula, se informará de dicha siatuación al usuario.
1. ***Obtener una lista de actores ordenada (nombre, apellido):* ** Obtenemos una lista de actores ordenados bajo el criterio: Nombre Apellido (separados unicamente por un espacio)
1. ***Exportar los datos a un fichero de texto:* ** Exportamos la lista ordenada de los actores, con sus respetivas peliculas a un fichero de texto `.txt`


* * *

## 2. Diagrama de clases

Este es el diseño final del programa, los diseños iniciales y la evolución de los mismos hasta llegar a esta se encuentran en nuestro GitHub.

![](/Users/Josu/IdeaProjects/EDA16-17/src/lab1/diagram.png)


* * *


## 3. Descripción de las estructuras de datos principales

Como comentábamos en la introducción del documento, **la parte más importante** del documento recae en los métodos que realizan **las búsquedas**. Dado que **son necesarios para trabajar la información, añadir y eliminarla**.

Para trabajar las búsquedas **inicialmente lo hacíamos mediante búsquedas lineales**, pero viendo que **el coste del mismo se disparaba al trabajar con grandes cantidades de datos**; **decidimos optar por usar el algoritmo de búsqueda binaria** (que solo funciona si la lista esta previamente ordenada). La **búsqueda lineal tenía un coste de *O(n)* mientras que la dicotómica/binaria *O(log n)* **.
**Finalmente, vimos que podriamos tratar las búsquedas casi como un coste constante** si utilizabamos alguna estructura de datos de la familia **'Map'**. Por eso, replanteamos el diseño del programa e **hicimos que todas las estructuras de datos con las que trabajamos sean *HashMap < String, T >* ** donde 'T' es cualquier objeto que necesitemos almacenar (peliculas, actores...).

Teniendo en cuenta que:
- **n** es el numero de peliculas que hay en el fichero
- **m** es el numero de actores que por pelicula del fichero (n)

**Utilizando HashMap como estructura** de datos contenedora, el proceso de **cargar el fichero tiene un coste de *O(n*m)* **.Por un lado recorremos completamente el fichero de datos y por otro, tenemos que recorrer completamente la lista que estamos creando e inicializando con los datos del fichero. Al hacerlo mediante un hashmap, nos ahorramos la variable ‘p’ en el coste, dado que no tenemos que recorrer la listaAux (por que es un hashmap).

Como **algoritmo de ordenación**, utilizábamos BubbleSort. Este, habia sido el algoritmo con el que mas habíamos trabajo y con el que mas cómodos nos sentiamos, pero al igual que en el anterior caso, decidimos hacer modificaciones debido a que su coste era demasiado alto para lo que buscábamos O(n2). Hicimos distintas pruebas con MergeSort, aunque **finalmente optamos como algoritmo por el QuickSort reduciendo así el coste hasta O(n* log n)**.
Para realizar **la operación de ordenación**, previamente **volcamos las claves de nuestro HashMap** (que son los nombres de los actores) **en un Array[] de String y procedemos a ordenarlo**. **Tras esto, recibiremos una lista de claves ordenadas**, que en caso de querer mostrar unicamente los nombres de los actores cumple al 100% la función y en caso de querer mostrar mas información, lo recorreremos en orden y accederemos con cada clave a la información de nuestro catálogo (HashMap).

## 4. Diseño e implementacion de los metodos principales

Este apartado lo dedicaremos a explicar el funcionamiento de diferentes métodos principales, así como: readFile(), addActor(), removeActor(), searchActor() y quickSortList().

###4.1. readFile():

####4.1.1 Precondicion/Postcondicion
++Precondicion:++ Tendremos un fichero
++Postcondicion:++ El programa habra leido el fichero

####4.1.2 Casos de prueba
* Archivo null
* Archivo correcto
 * Tras analizar el fichero, asumimos la posicion predefinida de los caracteres especiales.

####4.1.3 Coste

Inicialmente deficimos hacer la lectura del fichero con un FileReader, pero acabamos viendo que no era eficiente (tiempos medios de 90s), también probamos con el metodo readAllLines() y volcarlo sobre una lista (34s aprox.), pero finalmente hemos optado por volcar en una lista (List< String >) el contenido de un BuffererReader e iterar sobre el con un *for* hasta llegar al final del documento a leer.

Este algoritmo tratara de leer un fichero .txt en el que aparecen nombres de peliculas, y los actores que participan en ellas. Por ello, el programa estimamos que tendrá un coste de ***O(n x m)* **, donde n es la cantidad de actores, y m es la cantidad de peliculas.

####4.1.4 Pseudo-algoritmo

		new BufferedReader(FileReaderDelFicheroQueQueremosLeer)
        contLineas = contadorLineas(nuevo File("Direccion"))
        auxCont = 0

		mientras siguienteLinea != null
        	guardamos en auxLinea1 = siguienteLinea.split (" ---> ") la linea separadas 		  	en: nombre de pelicula y actores
        	si opcion == 1 entonces
    	   	Normalizamos()
			fin si
        	nombrePelicula = auxLinea1[0]
			guardamos en auxLine2 = auxLinea1[1].split(" &&& ") los nombres de los 			 actores que participan en la pelicula en cuestión.
        	creamos auxFilm = Film(nombrePelicula)
       	 CatalogoPeliculas.getMiCatalogoPeliculas().añadirPelicula(auxFilm)
    	    creamos varable temporal i = 0 como contador
     	   mientras(auxLine2.lenght > i)
      	  	nombreActor = auxLine2[i]
        	    apellidoActor = ""
            	si (nombreActor.contiene("(")) entonces
            		auxLinea1 = nombreActor.split(" (")
                	nombreActor = auxLinea1[0]
           	 fin si
            	si (nombreActor.contiene(",")) entonces
            		auxLinea1 = nombreActor.split(", ")
                	si(auxLinea1.length > 1) entonces
                    	si(auxLinea1[1].comparar("null") != 0) entonces
                        	apellidoActor = auxLinea1[0]
                            nombreActor = auxLinea1[1]
                        si no
                        	nombreActor = auxLinea[0]
                        fin si
                   fin si
				fin si
            	auxActor = nuevo Actor(nombreActor, apellidoActor)
                si (opcion = 1) entonces
                	si (!auxActor.getNombre().contiene("�")) entonces
                    	si(auxActor.getName().charEn(0) > 'A' && 												auxActor.getName().charEn(0) < 'Z') entonces
                        	auxActor.obtenerListaPeliculas().añadirPelicula(auxFilm)
                            CatalogoActores.getMiCatalogoActores().añadirActor(auxActor)
                            si (!auxFilm.getName().contiene("�")) entonces
                            	CatalogoPelis.getMiCatalogoPelis().getPelicula(auxFilm.g							etName()).getListaActores().añadirActor(auxActor)
                            fin si
                       fin si
                   fin si
				si no
					auxActor.getListaPeliculas().añadirPelicula(auxFilm)
                	CatalogoActores.getMiCatalogoActores().addActor(auxActor)
                	CatalogoPelis.getMiCatalogoPelis().getPelicula(auxFilm.getNombre()).				getListaActores().addActor(auxActor)
               fin si
               i++
        	fin mientras
        	si (j==0) entonces
        		System.out.println("\t[*] 0% file readed")
			fin si
        	si (((j*100)/contLineas) % 5 == 0) entonces
        		si(((j*100)/contLineas) != auxCont) entonces
            		auxCont = ((j*100)(contLineas))
                	Long stopTime = System.currentTimeMilis()
                	total = (int) (stopTime - startTime) / 1000
                	System.out.println("\t[*] " + auxCont + "% file readed. Time elapsed				: " + total + "s")
            	fin si
        	si no, si (((j*100)/contLineas) % 5 == 0) entonces
       	 	JMenu.getMiJMenu().actualizarBarra((j * 100) / contLineas)
			fin si
		fin mientras

####4.1.5 Método final

```java
public void readFile(int pOption) throws IOException {

        String[] auxLine1;

        long startTime = System.currentTimeMillis();

        int j = 0; //j= counts the actual line of file
        int total = 0; //total = saves total running time of reading
        int auxCont = 0;  //auxCount = saves the percentage of reading of file

        try (InputStream resource = FileManager.class.getResourceAsStream("testAllActors.txt")) {

            int contLines = countLines(new File("/Users/Josu/IdeaProjects/EDA16-17/src/lab1/testAllActors.txt"));

            String filmName, actorName, actorSurname;

            String[] auxLine2;

            Film auxFilm;

            List<String> lines = new BufferedReader(new InputStreamReader(resource, StandardCharsets.UTF_8)).lines().collect(Collectors.toList());

            for (String line : lines) {

                auxLine1 = line.split("\\s+\\--->+\\s"); //we split to get the name of the movie

                if (pOption == 1) {
                    NormalizeStrings.getMyNormalizeString().run(auxLine1);
                }

                filmName = auxLine1[0]; //here we save the name of the film

                auxLine2 = auxLine1[1].split("\\s+\\&&&+\\s"); //we split the array of actors in

                auxFilm = new Film(filmName); //create a new film

                if (pOption == 1) {
                    if (!auxFilm.getName().contains("�")) {
                        FilmCatalog.getMyFilmCatalog().addFilm(auxFilm); //we add the film if its not been added before
                    }
                } else {
                    FilmCatalog.getMyFilmCatalog().addFilm(auxFilm); //we add the film if its not been added before
                }

                int i = 0;

                while (auxLine2.length > i) { // mientras el indice no sea mayor que el tamaño de la lista(indexOutOfBoundException)

                    actorSurname = "";
                    actorName = auxLine2[i];

                    if (actorName.contains("(")) {
                        auxLine1 = actorName.split("\\s\\(");
                        actorName = auxLine1[0];
                    }
                    if (actorName.contains(",")) {//convertimos -> Apellido, Nombre --> Nombre, Apellido (como es habitual)
                        auxLine1 = actorName.split(",\\s*");
                        if (auxLine1.length > 1) {
                            if (auxLine1[1].compareToIgnoreCase("null") != 0) {
                                actorSurname = auxLine1[0];
                                actorName = auxLine1[1];
                            } else {
                                actorName = auxLine1[0];
                            }
                        }
                    }
                    Actor auxActor = new Actor(actorName, actorSurname);//Creamos la pelicula enviandole el nombre una vez normalizado

                    if (pOption == 1) {
                        if (!auxActor.getName().contains("�")) {
                            if (auxActor.getName().charAt(0) > 'A' && auxActor.getName().charAt(0) < 'Z') {
                                auxActor.getFilmList().addFilm(auxFilm);
                                ActorCatalog.getmyActorCatalog().addActor(auxActor);
                                if (!auxFilm.getName().contains("�")) {
                                    FilmCatalog.getMyFilmCatalog().getFilm(auxFilm.getName()).getActorList().addActor(auxActor);
                                }
                            }
                        }
                    } else {
                        auxActor.getFilmList().addFilm(auxFilm);
                        ActorCatalog.getmyActorCatalog().addActor(auxActor);
                        FilmCatalog.getMyFilmCatalog().getFilm(auxFilm.getName()).getActorList().addActor(auxActor);
                    }

                    i++;

                }
                if (j == 0) {
                    System.out.println("\t[*] 0% file readed");
                }
                j++;

                if (((j * 100) / contLines) % 5 == 0) {
                    if (((j * 100) / contLines) != auxCont) {
                        auxCont = ((j * 100) / contLines);
                        long stopTime = System.currentTimeMillis();
                        total = (int) (stopTime - startTime) / 1000;

                        System.out.println("\t[*] " + auxCont + "% file readed. Time elapsed: " + total + "s");
                    }
                } else if (((j * 100) / contLines) % 5 == 0) {
                    SwingGUI.getMyJMenu().updateBar((j * 100) / contLines);
                }
            }
        }
        System.out.println("\t-------- File read finished --------\n");
        System.out.println("\t--- Elapsed time to read the file ---> " + total + "s---");
        System.out.println("\t--- Total actor/actresses found :" + ActorCatalog.getmyActorCatalog().getActorL().size());
        System.out.println("\t--- Total films found : " + FilmCatalog.getMyFilmCatalog().getSize());
    }

```
### 4.2 buscarActor(String nombreActor)
#### 4.2.1 Precondición/Postcondición
- ++Pre:++ La lista no esta ordenada. No se repiten elementos.
- ++Post:++ Obtenemos un actor de la lista en caso de existir, en caso contario obtendremos null.

#### 4.2.2 Casos de prueba
- El elemento no está en la lista
- El elemento está en la lista
	- Es el primero de la lista
	- Está en una posición aleatoria (middle) o Es el último de la lista

#### 4.2.3 Coste

Tenemos los actores guardados en una estructura de datos de tipo ***HashMap < String, Actor >* **, no es necesario hacer una 'busqueda' en si misma. Se reduce a acceder a un dato desde una clave.
El coste del algoritmo por lo tanto, es ***O(1)* **.

#### 4.2.4 Pseudo-algoritmo

```
clase publica buscarActor (String nombreActor)
	si (listaActores.obtener(nombreActor) es distinto de null entonces
    	devuelve listaActores.obtener(nombreActor)
    si no
    	devuelve null

```

#### 4.2.5 Metodo final (código)

```java
public Actor searchActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            return this.actorL.get(pActor.getName() + " " + pActor.getSurname());
        }
        return null;
}

```

Este método, utiliza otro método definido previamente:

```java
private boolean exist(String pActorName, String pActorSurname) {
	return actorL.get(pActorName + " " + pActorSurname) != null;
}

```

* * *
###4.3 addActor()


####4.3.1 Precondicion/Postcondicion
- ++Precondicion:++ Tendremos un actor.
- ++Postcondicion:++ El programa habra añadido el actor a la lista.

####4.3.2 Casos de prueba
* Actor null
* Actor existente ya en la lista
* Nombre vacio

####4.3.3 Coste
Este método recibirá un objeto pActor, y lo que tendrá que hacer es comprobar si ese actor ya existe en el catálogo, y para ello, al estar usando estructuras HashMap, el coste que tendrá será constante; por consiguiente el coste del método completo de añadirActor() será lineal ya que la otra llamada de la que hacemos uso es put() que no aumentara apenas el coste.

####4.3.4 Pseudo-algoritmo

	si (!this.existe(pActor.getNombre(), pActor.getApellido)) entonces
    	this.listaActores.poner(pActor.getNombre() + " "+pActor.getApellido(), pActor)
    fin si


####4.3.5 Método final

```java
 public void addActor(Actor pActor) {
        if (!this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.put(pActor.getName() + " " + pActor.getSurname(), pActor);
        }
 }

```

##4.5 sortImpl()

###4.5.1 Precondicion/PostCondicion
- ++Precondición++: El programa recibe un array de Strings que tendrá los nombres de los actores, y dos números que nos servirán de índices.
- ++Postcondición++: Tras ejecutar el programa nuestro cátalogo de actores estará ordenado alfabeticamente.

###4.5.2 Casos de prueba
* Lista vacía
* Lista no vacía.

###4.5.3 Coste

En el mejor caso, el pivote termina en el centro de la lista, dividiéndola en dos sublistas de igual tamaño. En este caso, el orden de complejidad del algoritmo es ***O(n·log n)* **.
En el peor caso, el pivote termina en un extremo de la lista. El orden de complejidad del algoritmo es entonces de ***O(n²)* **. El peor caso dependerá de la implementación del algoritmo, aunque habitualmente ocurre en listas que se encuentran ordenadas, o casi ordenadas.
En el caso promedio, el orden es ***O(n·log n)* **.

###4.5.4 Pseudo-algoritmo

	 private static void sortImpl(String[] array, int pivoteInicio, int pivoteFinal, int tamañoString) throws NullPointerException {


		int rango = pivoteFinal - pivoteInicio
        
		si (rango < 2) entonces
        	return;
        fin si

		int selec = pivoteInicio

        mientras(int index = pivoteInicio; index < pivoteFinal; ++index)
        	String actual = array(index)
            si(actual.length() == stringLength) entonces
            	String temp = array[selec]
                array[selec] = actual
                array[index] = tmp
                ++finger
            fin si
       fin mientras
       
		pivoteInicio = selec
       
        String izq = array[pivoteInicio];
        String dcha = array[pivoteFinal - 1];
        String medio = array[pivoteInicio + rango >> 1];

        String pivote = medio(izq, medio, dhca);
        
		mientras (int index = pivoteInicio; index < pivoteFinal; ++index)
        	String actual = array[index]
            
            si(actual.charEn(tamañoString) < pivote.charEn(tamañoString)) entonces
            	String tmp=array[selec]
                array[selec] = actual
                array[index] = tmp
				++finger
            fin si
        fin mientras
        
        sortImpl(array, pivoteInicio, selec, tamañoString)

        pivoteInicio = selec

        mientras (int index = pivoteInicio; index < pivoteFinal; ++index)
        	String actual = array[index]
			
            si (actual.charEn(tamañoString) == pivote.charEn(tamañoString)) entonces
            	String tmp = array[selec]
                array[selec] = actual
                array[index] = tmp
                ++finger
            fin si
        fin mientras    
          
		sortImp(array, pivoteInicio, selec, tamañoString + 1)
        sortImpl(array, selec, pivoteFinal, tamañoString)
   	}
    
    
###4.5.5 Método final

```java
private static void sortImpl(String[] array, int fromIndex, int toIndex, int stringLength) throws NullPointerException {



        int rangeLength = toIndex - fromIndex;

        if (rangeLength < 2) {
            return;
        }

        int finger = fromIndex;

        // Put all strings of length 'stringLength' to the beginning of the
        // requested sort range.
        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];
            if (current.length() == stringLength) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        fromIndex = finger;

        // Choose a pivot string by median.
        String probeLeft = array[fromIndex];
        String probeRight = array[toIndex - 1];
        String probeMiddle = array[fromIndex + rangeLength >> 1];

        String pivot = median(probeLeft, probeMiddle, probeRight);

        // Process strings S for which S[stringLength] < X[stringLength].
        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];

            if (current.charAt(stringLength) < pivot.charAt(stringLength)) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        sortImpl(array, fromIndex, finger, stringLength);

        fromIndex = finger;

        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];

            if (current.charAt(stringLength) == pivot.charAt(stringLength)) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        sortImpl(array, fromIndex, finger, stringLength + 1);
        sortImpl(array, finger, toIndex, stringLength);
    }

```

###4.6 contLines()

###4.6.1 Precondición/Postcondición
* ++Precondición++: Tenemos un fichero.
* ++Postcondición++: Nos devolverá la cantidad de lineas que tiene.

###4.6.2 Explicacion del algoritmo

Para evitar sobrecargar la pantalla de la consola, ralentizar la carga de datos y asi mismo hacerla mas trasparente para el usuario, hemos decidido implementar un contador de lineas que combinado con la linea actual y un submetodo que acompaña, imprime por pantalla la información relativa a la carga del fichero en bloques de `%5`.

###4.6.4 Código

Metodo que lee todas las lineas y nos devuelve un *int*, siendo este el numero de lineas totales del fichero a cargar.

```java
 public static int countLines(File pFile) throws IOException {
        LineNumberReader lnr = new LineNumberReader(new FileReader(pFile));
        lnr.skip(Long.MAX_VALUE);
        lnr.close();
        return lnr.getLineNumber() + 1;//Add 1 because line index starts at 0
    }
```
Este es el submetodo que es llamado en las iteraciones de la carga para mostrar la información por pantalla al usuario (en bloques de `5%`)

```java
    if (((i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size()) % 5 == 0) {
    	if (((i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size()) != percentage) {
    		System.out.println("\t\t[*] " + percentage + "%");
          }
    }    

```

## 5. Código completo

- Se incluye el **diagrama de clases** completo en formato `.png`
- **Los ficheros `.java`** que contienen todos los métodos
- **Los ficheros resultado** de la carga del fichero original
	- Fichero resultado con los actores y peliculas con nombres normalizados (y descartando aquellos que tras el proceso seguian estando mal escritos)
	- Fichero resultado con todos los actores y peliculas que nuestro programa trata en la carga

### 5.1 Actor
```java
public class Actor {

    private String name;
    private String surname;
    private FilmList filmL;

    public Actor(String pName, String pSurname) {
        this.name = pName;
        this.surname = pSurname;
        this.filmL = new FilmList();
    }

    public FilmList getFilmList() {
        return this.filmL;
    }

    public String getName() {
        return this.name;
    }

    public String getSurname() {
        return this.surname;
    }
}

```

### 5.2 ActorCatalog
```java
public class ActorCatalog {

    private static ActorCatalog myActorCatalog;
    private HashMap<String, Actor> actorL;

    private ActorCatalog() {
        this.actorL = new HashMap<>();
    }

    public static ActorCatalog getmyActorCatalog() {
        if (myActorCatalog == null) {
            myActorCatalog = new ActorCatalog();
        }
        return myActorCatalog;
    }

    public HashMap<String, Actor> getActorL() {
        return this.actorL;
    }

    private boolean exist(String pActorName, String pActorSurname) {
        return actorL.get(pActorName + " " + pActorSurname) != null;
    }

    public void addActor(Actor pActor) {
        if (!this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.put(pActor.getName() + " " + pActor.getSurname(), pActor);
        }
    }

    public Actor searchActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            return this.actorL.get(pActor.getName() + " " + pActor.getSurname());
        }
        return null;
    }

    public void removeActor(Actor pActor) {
        if (this.exist(pActor.getName(), pActor.getSurname())) {
            this.actorL.remove(pActor.getName() + " " + pActor.getSurname());
            System.out.println("Actor erased");
        } else {
            System.out.println("Actor not found");
        }
    }

    public String[] quickSortList() {
        String[] auxS = new String[actorL.size()];
        int i = 0;
        for (String key : actorL.keySet()) {
            auxS[i] = key;
            i++;
        }
        StringQuickSort.sort(auxS);
        return auxS;
    }

    public void printList(String[] auxS) {
        for (String key : auxS) {
            System.out.println(key);
        }
    }
}
```
### 5.3 ActorList
```java
public class ActorList {

    private HashMap<String, Actor> actorList;


    public ActorList() {
        this.actorList = new HashMap<>();
    }


    public boolean exist(String pActorName, String pActorSurname) {
        return this.actorList.get(pActorName + " " + pActorSurname) != null;
    }

    public void addActor(Actor auxActor) {
        if (!this.exist(auxActor.getName(), auxActor.getSurname())) {
            this.actorList.put(auxActor.getName() + " " + auxActor.getSurname(), auxActor);
        }
    }

    public Actor getActor(String pActorName, String pActorSurname) {
        if (this.actorList.get(pActorName + " " + pActorSurname) != null) {
            return actorList.get(pActorName);
        }
        return null;
    }

    public void removeActor(Actor pActor) {
        if (this.actorList.get(pActor.getName() + " " + pActor.getSurname()) != null) {
            this.actorList.remove(pActor.getName() + " " + pActor.getSurname());
        }
    }

    public void printActors() {
        System.out.println("These are all the actors: ");
        for (HashMap.Entry<String, Actor> entry : actorList.entrySet()) {
            String key = entry.getKey();
            System.out.println(key.toString());
        }
    }
}
```
### 5.4 EDA1617
```java
public class EDA1516 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {

        Object[] options = {"GUI based", "Console based"};

        //int n = JOptionPane.showOptionDialog(null,"Choose what launcher do you want to use", "EDA16-17 Selection Menu",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[1])

        System.out.println("\t\t***** Welcome to EDA16/17 project *****\n");

        System.out.println("\tSelect (1) for gui based program launch (still in development, less customizable)");
        System.out.println("\tSelect (2) for terminal based program launch (finished and more customizable experience");

        int n = Keyboard.getMyKeyboard().getInt();

        if (n == 1) {

            JFrame frame = SwingGUI.getMyJMenu();

            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();         //En dim guardamos el tamaño de la pantalla donde se esta ejecutando el programa

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //fijamos que la operacion por defecto al cerrar es salir
            frame.pack();
            frame.isAlwaysOnTop();
            frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);         //Fijamos por defecto que la ventana siempre aparezca en el centro
            frame.setVisible(true); //hacemos el frame visible
            frame.setResizable(false);
        } else {
            TerminalUI.main();
        }
    }
}
```
### 5.5 FileManager
```java
public class FileManager {

    private static FileManager myFileManager;

    private FileManager() {

    }

    public static FileManager getMyFileManager() {
        if (myFileManager == null) {
            myFileManager = new FileManager();
        }
        return myFileManager;
    }

    public static int countLines(File pFile) throws IOException {
        LineNumberReader lnr = new LineNumberReader(new FileReader(pFile));
        lnr.skip(Long.MAX_VALUE);
        lnr.close();
        return lnr.getLineNumber() + 1;//Add 1 because line index starts at 0
    }

    public void readFile(int pOption) throws IOException {

        String[] auxLine1;

        long startTime = System.currentTimeMillis();

        int j = 0; //j= counts the actual line of file
        int total = 0; //total = saves total running time of reading
        int auxCont = 0;  //auxCount = saves the percentage of reading of file

        try (InputStream resource = FileManager.class.getResourceAsStream("testAllActors.txt")) {

            int contLines = countLines(new File("/Users/Josu/IdeaProjects/EDA16-17/src/lab1/testAllActors.txt"));

            String filmName, actorName, actorSurname;

            String[] auxLine2;

            Film auxFilm;

            List<String> lines = new BufferedReader(new InputStreamReader(resource, StandardCharsets.UTF_8)).lines().collect(Collectors.toList());

            for (String line : lines) {

                auxLine1 = line.split("\\s+\\--->+\\s"); //we split to get the name of the movie

                if (pOption == 1) {
                    NormalizeStrings.getMyNormalizeString().run(auxLine1);
                }

                filmName = auxLine1[0]; //here we save the name of the film

                auxLine2 = auxLine1[1].split("\\s+\\&&&+\\s"); //we split the array of actors in

                auxFilm = new Film(filmName); //create a new film

                if (pOption == 1) {
                    if (!auxFilm.getName().contains("�")) {
                        FilmCatalog.getMyFilmCatalog().addFilm(auxFilm); //we add the film if its not been added before
                    }
                } else {
                    FilmCatalog.getMyFilmCatalog().addFilm(auxFilm); //we add the film if its not been added before
                }

                int i = 0;

                while (auxLine2.length > i) { // mientras el indice no sea mayor que el tamaño de la lista(indexOutOfBoundException)

                    actorSurname = "";
                    actorName = auxLine2[i];

                    if (actorName.contains("(")) {
                        auxLine1 = actorName.split("\\s\\(");
                        actorName = auxLine1[0];
                    }
                    if (actorName.contains(",")) {//convertimos -> Apellido, Nombre --> Nombre, Apellido (como es habitual)
                        auxLine1 = actorName.split(",\\s*");
                        if (auxLine1.length > 1) {
                            if (auxLine1[1].compareToIgnoreCase("null") != 0) {
                                actorSurname = auxLine1[0];
                                actorName = auxLine1[1];
                            } else {
                                actorName = auxLine1[0];
                            }
                        }
                    }
                    Actor auxActor = new Actor(actorName, actorSurname);//Creamos la pelicula enviandole el nombre una vez normalizado

                    if (pOption == 1) {
                        if (!auxActor.getName().contains("�")) {
                            if (auxActor.getName().charAt(0) > 'A' && auxActor.getName().charAt(0) < 'Z') {
                                auxActor.getFilmList().addFilm(auxFilm);
                                ActorCatalog.getmyActorCatalog().addActor(auxActor);
                                if (!auxFilm.getName().contains("�")) {
                                    FilmCatalog.getMyFilmCatalog().getFilm(auxFilm.getName()).getActorList().addActor(auxActor);
                                }
                            }
                        }
                    } else {
                        auxActor.getFilmList().addFilm(auxFilm);
                        ActorCatalog.getmyActorCatalog().addActor(auxActor);
                        FilmCatalog.getMyFilmCatalog().getFilm(auxFilm.getName()).getActorList().addActor(auxActor);
                    }

                    i++;

                }
                if (j == 0) {
                    System.out.println("\t[*] 0% file readed");
                }
                j++;

                if (((j * 100) / contLines) % 5 == 0) {
                    if (((j * 100) / contLines) != auxCont) {
                        auxCont = ((j * 100) / contLines);
                        long stopTime = System.currentTimeMillis();
                        total = (int) (stopTime - startTime) / 1000;

                        System.out.println("\t[*] " + auxCont + "% file readed. Time elapsed: " + total + "s");
                    }
                } else if (((j * 100) / contLines) % 5 == 0) {
                    SwingGUI.getMyJMenu().updateBar((j * 100) / contLines);
                }
            }
        }
        System.out.println("\t-------- File read finished --------\n");
        System.out.println("\t--- Elapsed time to read the file ---> " + total + "s---");
        System.out.println("\t--- Total actor/actresses found :" + ActorCatalog.getmyActorCatalog().getActorL().size());
        System.out.println("\t--- Total films found : " + FilmCatalog.getMyFilmCatalog().getSize());
    }

    @SuppressWarnings("rawtypes")
    public void exportToFile() {

        String[] keys = ActorCatalog.getmyActorCatalog().quickSortList();

        FileWriter fichero = null;
        PrintWriter pw;

        long timeStart = System.currentTimeMillis();

        try {
            String directorio = System.getProperty("user.dir");//cogemos variable entorno
            fichero = new FileWriter(directorio + "/ActorList_ordered.txt");
            pw = new PrintWriter(fichero);

            int i = 1;
            for (int i1 = 0, keysLength = keys.length; i1 < keysLength; i1++) {
                Object key = keys[i1];
                pw.print("Actor " + i + " -> ");
                pw.println(ActorCatalog.getmyActorCatalog().getActorL().get(key).getName() + " " + ActorCatalog.getmyActorCatalog().getActorL().get(key).getSurname());
                Object[] keys2;
                keys2 = ActorCatalog.getmyActorCatalog().getActorL().get(key).getFilmList().getFilmL().keySet().toArray();
                for (Object auxKey : keys2) {
                    pw.println("\t" + ActorCatalog.getmyActorCatalog().getActorL().get(key).getFilmList().getFilmL().get(auxKey).getName());
                }
                i++;
                int percentage = (i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size();
                if (((i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size()) % 5 == 0) {
                    if (((i * 100) / ActorCatalog.getmyActorCatalog().getActorL().size()) != percentage) {
                        System.out.println("\t\t[*] " + percentage + "%");
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != fichero) {
                    fichero.close();
                }
                long timeTotal = (System.currentTimeMillis() - timeStart);
                System.out.println("\t\t --- Elapsed time to export the file --- : " + (int) timeTotal / 1000 + "sec, " + timeTotal * 1000 + "ms\n");
                System.out.println("\n\tFile exported to: " + System.getProperty("user.dir"));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
}
```
### 5.6 Film
```java
public class Film {
    private String name;
    private int earned = 0;
    private ActorList actorList;

    public Film(String pName) {
        this.name = pName;
        this.actorList = new ActorList();
    }

    public String getName() {
        return this.name;
    }

    public int getEarned() {
        return this.earned;
    }

    public void incrementEarned(int auxEarned) {
        this.earned += auxEarned;
    }

    public ActorList getActorList() {
        return this.actorList;
    }
}
```
### 5.7 FilmCatalog
```java
public class FilmCatalog {

    private static FilmCatalog myFilmCatalog;
    private HashMap<String, Film> filmL;

    private FilmCatalog() {
        this.filmL = new HashMap<>();
    }

    public static FilmCatalog getMyFilmCatalog() {
        if (myFilmCatalog == null) {
            myFilmCatalog = new FilmCatalog();
        }
        return myFilmCatalog;
    }

    public boolean exist(String pFilmName) {
        return filmL.get(pFilmName) != null;
    }

    public void addFilm(Film pFilm) {
        if (!this.exist(pFilm.getName())) {
            this.filmL.put(pFilm.getName(), pFilm);
        }
    }

    public Film getFilm(String pFilmName) {
        if (this.exist(pFilmName)) {
            return this.filmL.get(pFilmName);
        }
        return null;
    }

    public int getSize(){
        return this.filmL.size();
    }
}
```
### 5.8 FilmList
```java
public class FilmList {

    private HashMap<String, Film> filmL;

    public FilmList() {
        this.filmL = new HashMap<>();
    }


    private boolean exist(String pFilmName) {
        return this.filmL.get(pFilmName) != null;
    }

    public void addFilm(Film pFilm) {
        if (!this.exist(pFilm.getName())) {
            this.filmL.put(pFilm.getName(), pFilm);
        }
    }

    public Film getFilm(String pFilmName) {
        if (this.filmL.get(pFilmName) != null) {
            return this.filmL.get(pFilmName);
        }
        return null;
    }

    public HashMap<String, Film> getFilmL() {
        return this.filmL;
    }

    public void printFilms() {
        System.out.println("These are all the films: ");
        for (HashMap.Entry<String, Film> entry : filmL.entrySet()) {
            String key = entry.getKey();
            System.out.println(key.toString());
        }
    }
}
```
### 5.9 Keyboard
```java
public class Keyboard {

	private static Keyboard miKeyboard;
	private Scanner scan;
	
	public Keyboard(){
		scan = new Scanner(System.in);
	}
	
	public static Keyboard getMyKeyboard(){
		if (miKeyboard==null){
			miKeyboard = new Keyboard();
		}
		return miKeyboard;
	}

	public int getInt(){
		String auxS = scan.nextLine();
		while(!this.isNumeric(auxS)){
			try{
				Integer.parseInt(auxS);
			}
			catch (NumberFormatException nfe){
				System.out.println("Insert a valid number");
				auxS = scan.nextLine();
			}
		}
		int resul = Integer.parseInt(auxS);
		return resul;
	}
    
	private boolean isNumeric(String cadena){
		try{
			Integer.parseInt(cadena);
			return true;
		}
		catch(NumberFormatException nfe){
			return false;
		}
	}
	
	public String getString(){
		String auxS = scan.nextLine();
		return auxS;
	}
}
```
### 5.10 NormalizeStrings
```java
public class NormalizeStrings extends Thread {

    private static NormalizeStrings myNormalizeString;

    public static NormalizeStrings getMyNormalizeString() {
        if (myNormalizeString == null) {
            myNormalizeString = new NormalizeStrings();
        }
        return myNormalizeString;
    }

    public void run(String[] pLine) {

        for (int i = 0; i < pLine.length; i++) {
            if (pLine[i].contains("Ã¡")) {
                pLine[i].replaceAll("Ã¡", "a");
            } else if (pLine[i].contains("Ã©")) {
                pLine[i].replaceAll("Ã©", "e");
            } else if (pLine[i].contains("Ã­")) {
                pLine[i].replaceAll("Ã­", "i");
            } else if (pLine[i].contains("Ã³")) {
                pLine[i].replaceAll("Ã³", "o");
            } else if (pLine[i].contains("Ãº")) {
                pLine[i].replaceAll("Ãº", "u");
            } else if (pLine[i].contains("Ã�")) {
                pLine[i].replaceAll("Ã�", "A");
            } else if (pLine[i].contains("Ã‰")) {
                pLine[i].replaceAll("Ã‰", "E");
            } else if (pLine[i].contains("Ã�")) {
                pLine[i].replaceAll("Ã�", "I");
            } else if (pLine[i].contains("Ã“")) {
                pLine[i].replaceAll("Ã“", "O");
            } else if (pLine[i].contains("Ãš")) {
                pLine[i].replaceAll("Ãš", "U");
            } else if (pLine[i].contains("Ã§")) {
                pLine[i].replaceAll("Ã§", "c");
            } else if (pLine[i].contains("Ã")) {
                pLine[i].replaceAll("Ã", "a");
            } else if (pLine[i].contains("Ã¨")) {
                pLine[i].replaceAll("Ã¨", "e");
            } else if (pLine[i].contains("Ã¬")) {
                pLine[i].replaceAll("Ã¬", "i");
            } else if (pLine[i].contains("Ã²")) {
                pLine[i].replaceAll("Ã²", "o");
            } else if (pLine[i].contains("Ã¹")) {
                pLine[i].replaceAll("Ã¹", "u");
            } else if (pLine[i].contains("Ã€")) {
                pLine[i].replaceAll("Ã€", "A");
            } else if (pLine[i].contains("Ãˆ")) {
                pLine[i].replaceAll("Ãˆ", "E");
            } else if (pLine[i].contains("ÃŒ")) {
                pLine[i].replaceAll("ÃŒ", "I");
            } else if (pLine[i].contains("Ã’")) {
                pLine[i].replaceAll("Ã’", "O");
            } else if (pLine[i].contains("Ã™")) {
                pLine[i].replaceAll("Ã™", "U");
            } else if (pLine[i].contains("Ã‡")) {
                pLine[i].replaceAll("Ã‡", "C");
            } else if (pLine[i].contains("�")) {
                pLine[i].replaceAll("�", "A");
            } else if (pLine[i].contains("�s")) {
                pLine[i].replaceAll("�s", "Os");
            }
            this.waitXseconds(0.1);
        }
    }

    private void waitXseconds(double ms) {
        try {
            Thread.sleep((long)ms * 10);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

}
```
### 5.11 StringQuickSort
```java
public class StringQuickSort {

    public static void sort(String[] array) {
        sort(array, 0, array.length);
    }

    private static void sort(String[] array, int fromIndex, int toIndex) {
        if (toIndex - fromIndex < 2) {
            return;
        }
        long timeStart = System.currentTimeMillis();
        sortImpl(array, fromIndex, toIndex, 0);
        long timeTotal = (System.currentTimeMillis() - timeStart);
        System.out.println("\t\t --- Elapsed time to order the actor list --- : " + (int) timeTotal / 1000 + "sec, " + timeTotal * 1000 + "ms\n");
    }

    private static void sortImpl(String[] array, int fromIndex, int toIndex, int stringLength) throws NullPointerException {



        int rangeLength = toIndex - fromIndex;

        if (rangeLength < 2) {
            return;
        }

        int finger = fromIndex;

        // Put all strings of length 'stringLength' to the beginning of the
        // requested sort range.
        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];
            if (current.length() == stringLength) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        fromIndex = finger;

        // Choose a pivot string by median.
        String probeLeft = array[fromIndex];
        String probeRight = array[toIndex - 1];
        String probeMiddle = array[fromIndex + rangeLength >> 1];

        String pivot = median(probeLeft, probeMiddle, probeRight);

        // Process strings S for which S[stringLength] < X[stringLength].
        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];

            if (current.charAt(stringLength) < pivot.charAt(stringLength)) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        sortImpl(array, fromIndex, finger, stringLength);

        fromIndex = finger;

        for (int index = fromIndex; index < toIndex; ++index) {
            String current = array[index];

            if (current.charAt(stringLength) == pivot.charAt(stringLength)) {
                String tmp = array[finger];
                array[finger] = current;
                array[index] = tmp;
                ++finger;
            }
        }

        sortImpl(array, fromIndex, finger, stringLength + 1);
        sortImpl(array, finger, toIndex, stringLength);
    }

    private static String median(String a, String b, String c) {
        if (a.compareTo(b) <= 0) {
            if (c.compareTo(a) <= 0) {
                return a;
            }
            return b.compareTo(c) <= 0 ? b : c;
        }

        if (c.compareTo(b) <= 0) {
            return b;
        }
        return a.compareTo(c) <= 0 ? a : c;
    }

}
```
### 5.12 SwingGUI
```java
public class SwingGUI extends javax.swing.JFrame {

    private static SwingGUI myJMenu;
    private javax.swing.JButton button1;
    private javax.swing.JButton button2;
    private javax.swing.JTextField button2textField;
    private javax.swing.JButton button3;
    private javax.swing.JTextField button3textField;
    private javax.swing.JButton button4;
    private javax.swing.JTextField button4textField;
    private javax.swing.JButton button5;
    private javax.swing.JTextField button5textField;
    private javax.swing.JButton button6;
    private javax.swing.JTextField button6textField;
    private javax.swing.JButton button7;
    private javax.swing.JTextField button7textField;
    private javax.swing.JButton button8;
    private javax.swing.JButton button9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JProgressBar jProgressBar;

    /**
     * Creates new form SwingGUI
     */
    public SwingGUI() {
        initComponents();
    }

    public static SwingGUI getMyJMenu() {
        if (myJMenu == null) {
            myJMenu = new SwingGUI();
        }
        return myJMenu;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        button1 = new javax.swing.JButton();
        button2 = new javax.swing.JButton();
        button3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        button4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        button5 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        button6 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        button7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        button8 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        button9 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jProgressBar = new javax.swing.JProgressBar();
        button2textField = new javax.swing.JTextField();
        button3textField = new javax.swing.JTextField();
        button4textField = new javax.swing.JTextField();
        button5textField = new javax.swing.JTextField();
        button6textField = new javax.swing.JTextField();
        button7textField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel1.setText("IMDb Actor/Movie Catalog - EDA16-17-  ");

        button1.setText("(1)");
        button1.addActionListener(evt -> button1ActionPerformed());

        button2.setText("(2)");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed();
            }
        });

        button3.setText("(3)");
        button3.addActionListener(evt -> button3ActionPerformed());

        jLabel2.setText("Read data from file");

        jLabel3.setText("Search for an actor/actress");

        jLabel4.setText("Add a new actor/actress");

        button4.setText("(4)");
        button4.addActionListener(evt -> button4ActionPerformed());

        jLabel5.setText("Search for films of a particular actor");

        button5.setText("(5)");
        button5.addActionListener(evt -> button5ActionPerformed());

        jLabel6.setText("Search for actors of a particular film");

        button6.setText("(6)");
        button6.addActionListener(evt -> button6ActionPerformed());


        jLabel7.setText("Increase the money raised by a film");

        button7.setText("(7)");
        button7.addActionListener(evt -> button7ActionPerformed());

        jLabel8.setText("Erase an actor/actress");

        button8.setText("(8)");
        button8.addActionListener(evt -> button8ActionPerformed());

        jLabel9.setText("Obtain an ordered list of actors (name, surname)");

        button9.setText("(9)");
        button9.addActionListener(evt -> button9ActionPerformed());

        jLabel10.setText("Save/Export the list to a file");

        button2textField.setText("Actor/Actress name to search for");

        button3textField.setText("Actor/Actress name to add");

        button4textField.setText("Name of the film");

        button5textField.setText("Name of the actor/actress");

        button6textField.setText("Amount of money to increase");
        button6textField.setVisible(false);

        button7textField.setText("Actor/Actress name to delete");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(106, 106, 106)
                                                .addComponent(jLabel1))
                                        .addGroup(layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(button9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                        .addComponent(button1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel2)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(jProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel3)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(button2textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel4)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button3textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel5)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button4textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel6)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button5textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel7)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button6textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel8)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(button7textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jLabel9)
                                                        .addComponent(jLabel10))))
                                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(button1)
                                                .addComponent(jLabel2))
                                        .addComponent(jProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button2)
                                        .addComponent(jLabel3)
                                        .addComponent(button2textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button3)
                                        .addComponent(jLabel4)
                                        .addComponent(button3textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button4)
                                        .addComponent(jLabel5)
                                        .addComponent(button4textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button5)
                                        .addComponent(jLabel6)
                                        .addComponent(button5textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button6)
                                        .addComponent(jLabel7)
                                        .addComponent(button6textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button7)
                                        .addComponent(jLabel8)
                                        .addComponent(button7textField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button8)
                                        .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(button9)
                                        .addComponent(jLabel10))
                                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }

    private void button1ActionPerformed( ) {
        try {
            jProgressBar.setMinimum(0);
            jProgressBar.setMaximum(100);
            FileManager.getMyFileManager().readFile(1);
        } catch (FileNotFoundException e1) {
            System.out.println("File not found. ¿Are you sure that you're opening the correct file?");
        } catch (IOException e2) {
            System.out.println("IOException when counting lines for the progress bar");
        }

    }

    private void button2ActionPerformed() {
        String auxActorName = button2textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        Actor actor = ActorCatalog.getmyActorCatalog().searchActor(auxActor);
        if (actor != null) {
            System.out.println("Actor finded. " + actor.getName() + " " + actor.getSurname());
        } else {
            System.out.println("Actor: " + button2textField.getText() + " not found");
        }
    }

    private void button3ActionPerformed() {
        String auxActorName = button3textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        if (ActorCatalog.getmyActorCatalog().searchActor(auxActor) != null) {
            System.out.println("Actor already exists");
        } else {
            ActorCatalog.getmyActorCatalog().addActor(auxActor);
        }
    }

    private void button4ActionPerformed() {
        String auxActorName = button4textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        Actor auxActor = new Actor(auxActorName, auxActorSurname);
        if (ActorCatalog.getmyActorCatalog().searchActor(auxActor) != null) {
            ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)).getFilmList().printFilms();
        } else {
            System.out.println("Not posible to erase. Actor doesn't exist");
        }

    }

    private void button5ActionPerformed() {
        String auxFilmName = button5textField.getText();
        if (FilmCatalog.getMyFilmCatalog().getFilm(auxFilmName) != null) {
            FilmCatalog.getMyFilmCatalog().getFilm(auxFilmName).getActorList().printActors();
        }
    }

    private void button6ActionPerformed() {
        JTextField filmName = new JTextField(15);
        JTextField moneyQuantity = new JTextField(15);

        JPanel myPanel = new JPanel();
        myPanel.add(new JLabel("Film name:"));
        myPanel.add(filmName);
        myPanel.add(Box.createHorizontalStrut(15)); // a spacer
        myPanel.add(new JLabel("Money quantity:"));
        myPanel.add(moneyQuantity);

        JOptionPane.showConfirmDialog(null, myPanel,
                "Please enter filmName and moneyQuantity values", JOptionPane.OK_CANCEL_OPTION);
        try {
            FilmCatalog.getMyFilmCatalog().getFilm(filmName.getText()).incrementEarned(Integer.parseInt(moneyQuantity.getText()));
            System.out.println("Total earned by the film: " + FilmCatalog.getMyFilmCatalog().getFilm(filmName.getText()).getEarned());
        } catch (NullPointerException e1) {
            System.out.println("File not found or invalid moneyQuantity");
        }
    }

    private void button7ActionPerformed() {
        String auxActorName = button7textField.getText();
        String[] auxActorArray = auxActorName.split("\\s");
        auxActorName = auxActorArray[0];
        String auxActorSurname = auxActorArray[1];
        try {
            ActorCatalog.getmyActorCatalog().removeActor(new Actor(auxActorName, auxActorSurname));
        } catch (NullPointerException e1) {
            System.out.println("Actor not found");
        }
    }

    private void button8ActionPerformed() {
        ActorCatalog.getmyActorCatalog().quickSortList();
    }

    private void button9ActionPerformed() {
        try {
            FileManager.getMyFileManager().exportToFile();
        } catch (Exception e1) {
            System.out.println("Error during operation");
        }
    }

    public void updateBar(int pNewValue) {
        jProgressBar.setValue(pNewValue);
    }
}
```
### 5.13 TerminalGUI
```java
public class TerminalUI {

    private static TerminalUI myTerminalGUI;
    private Scanner optMenu;

    private TerminalUI() {
        optMenu = new Scanner(System.in);
    }

    public static TerminalUI getMyTerminalGUI() {
        if (myTerminalGUI == null) {
            myTerminalGUI = new TerminalUI();
        }
        return myTerminalGUI;
    }

    public static void main() throws FileNotFoundException {

        String[] auxActorArray;
        String auxActorName;
        String auxActorSurname;

        String auxS;

        System.out.println("\t\t\t***-----Welcome to our IMDb EDA16/17 project menu-----***");

        do {
            System.out.println("\n\t\t\t----------MENU----------");
            System.out.println("\t\t1) Read data from file");
            System.out.println("\t\t2) Search for an actor/actress");
            System.out.println("\t\t3) Add a new actor/actress");
            System.out.println("\t\t4) Search for films of a particular actor");
            System.out.println("\t\t5) Search for actor of a particular film");
            System.out.println("\t\t6) Increase the money raised by a film");
            System.out.println("\t\t7) Erase an actor/actress");
            System.out.println("\t\t8) Obtain an ordered list of actor (name,surname)");
            System.out.println("\t\t9) Save/Export the new list to a file");

            int optMenu = Keyboard.getMyKeyboard().getInt();

            switch (optMenu) {
                case 0:
                    System.out.println("\t\t--- Saliendo del programa... ----");
                    break;
                case 1:
                    try {
                        System.out.println("\tSelect one of options below: ");
                        System.out.println("\t\t1) Read only the 'readable' actors/films (after trying to rescue some names from the codification, take only the 'full readables') ");
                        System.out.println("\t\t2) Read the full list of actors/movies (don't care if they're wrong written, after running our conversor");
                        int optMenu1 = 0;
                        while (optMenu1 < 1 || optMenu1 > 2) {
                            optMenu1 = Keyboard.getMyKeyboard().getInt();
                            if (optMenu1 == 1) {
                                FileManager.getMyFileManager().readFile(1);
                            } else if (optMenu1 == 2) {
                                FileManager.getMyFileManager().readFile(2);
                            } else {
                                System.out.println("Invalid option, try again. Select a number between 1-2 range");
                            }
                        }

                    } catch (FileNotFoundException e1) {
                        System.out.println("File not found. ¿Are you sure that you're opening the correct file?");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 2:
                    System.out.println("Enter the name of the actor you want to look for: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    Actor auxA = ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname));
                    if (auxA == null) {
                        System.out.println("Actor not finded: " + auxS);
                    } else {
                        System.out.println("Actor finded: " + auxA.getName());
                    }
                    break;
                case 3:
                    System.out.println("Enter the name of the actor that you want to add: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    if (ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)) != null) {
                        System.out.println("Actor: " + auxS + " already exist");
                    } else {
                        ActorCatalog.getmyActorCatalog().addActor(new Actor(auxActorName, auxActorSurname));
                        System.out.println("Actor: " + auxS + " added to the ActorCatalog");
                    }
                    break;
                case 4:
                    System.out.println("Enter the name of the actor whose films you want to know");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    if (ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)) != null) {
                        ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)).getFilmList().printFilms();
                    } else {
                        System.out.println("Actor: " + auxS + " do not exist in the ActorCatalog");
                    }
                    break;
                case 5:
                    System.out.println("Enter the film whose actors that do you want to know: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    if (FilmCatalog.getMyFilmCatalog().getFilm(auxS) != null) {
                        FilmCatalog.getMyFilmCatalog().getFilm(auxS).getActorList().printActors();
                    }
                    break;
                case 6:
                    System.out.println("Enter the film whose amount of earning you want to raise: ");
                    auxS = Keyboard.getMyKeyboard().getString();
                    System.out.println("Enter the amount of money that you want to increase: ");
                    int auxI = Keyboard.getMyKeyboard().getInt();
                    if (FilmCatalog.getMyFilmCatalog().exist(auxS)) {
                        FilmCatalog.getMyFilmCatalog().getFilm(auxS).incrementEarned(auxI);
                        System.out.println("Total earned by the film: " + FilmCatalog.getMyFilmCatalog().getFilm(auxS).getEarned());
                    } else {
                        System.out.println("File not found. Are you sure that you have written title correctly?");
                    }
                    break;
                case 7:
                    System.out.println("Enter the name of the actor that you want to remove");
                    auxS = Keyboard.getMyKeyboard().getString();
                    auxActorArray = auxS.split("\\s");
                    auxActorName = auxActorArray[0];
                    auxActorSurname = auxActorArray[1];
                    if (ActorCatalog.getmyActorCatalog().searchActor(new Actor(auxActorName, auxActorSurname)) != null) {
                        ActorCatalog.getmyActorCatalog().removeActor(new Actor(auxActorName, auxActorSurname));
                        System.out.println("Actor: " + auxS + " succesfully removed");
                    } else {
                        System.out.println("Actor: " + auxS + " do not exist in the ActorCatalog");
                    }
                    break;
                case 8:
                    ActorCatalog.getmyActorCatalog().quickSortList();
                    break;
                case 9:
                    FileManager.getMyFileManager().exportToFile();
                    break;
            }
        } while (1 != 0);
    }
}
```
## 6. Resultados de las pruebas

**Estos son los resultados de las pruebas**, en la etapa final de desarrollo (lo que estamos entregando) de la actividad. **Todos los tiempos que mostramos son medias** realizadas (entre 5-10 ejecuciones) **de la misma operación**. Las pruebas **se han realizado en diferentes equipos con diferentes sistemas operativos**, detallamos:

En el fichero normalizado encontramos **1 061 522** actores, **230 369** peliculas.
En el fichero sin normalizar (cogiento toda la informacion, independientemente de si estan bien escritos) encontramos **1 191 316** actores, **238 809** peliculas.

- **CPU**: Intel i5 6600K 3,9 GHz x 4 cores, **GPU:** nVidia GTX 970 4GB Strix,**RAM:** 16GB DDR5  2666, **SO:** *Windows 10 Pro x64*
	- Cargar fichero normalizado: 11sec
	- Cargar fichero completo: 11sec 
	- Ordenar lista normalizada de actores: 0sec, 609000ms
	- Ordenar lista completa de actores: 0sec, 688000ms
	- Exportar lista normalizada de actores: 1sec, 1282000ms
	- Exportar lista completa de actores: 1sec, 1672000ms 

- **CPU**: Intel i5 2,7 GHz x 2 cores, **GPU:** HD 6100,**RAM:** 8GB LPDDR3  1866, **SO:** *Mac OS Sierra (10.12)*
	- Cargar fichero normalizado: 20sec
	- Cargar fichero completo: 26sec
	- Ordenar lista normalizada de actores: 1sec, 1398000ms
	- Ordenar lista completa de actores: 1sec, 1376000ms
	- Exportar lista normalizada de actores: 12sec, 12976000ms
	- Exportar lista completa de actores: 21sec, 21158000ms

- **CPU**: Intel Atom Z3775 1,46 GHz x 2 cores, **GPU:** Intel HD Graphics (Bay Trail) (311 - 778 MHz),**RAM:** 2GB RAM 1333, **SO:** *Windows 10 Home x32*
	- Cargar fichero normalizado: 90sec
	- Cargar fichero completo: El ordenador no es capaz de leerlo
	- Ordenar lista normalizada de actores: 2sec, 2312000ms
	- Ordenar lista completa de actores: No es capaz de leer el fichero completo
	- Exportar lista normalizada de actores: 78sec, 78051000ms
	- Exportar lista completa de actores: No es posible leer el fichero completo

## 7. Conclusiones

Destacamos como bien hemos indicado, l**a importancia de las búsquedas en el funcionamiento de nuestro programa**. Al tener que trabajarlas tanto, es necesario optimizarlas al máximo para evitar tiempos de ejecución demasiado altos.

**Otro de los métodos con mucha importancia es cargarFichero()** dado que coge línea a línea el texto que hay en el fichero y lo trata. Es decir, elimina toda la información no relevante para el programa y añade la que si tiene importancia.
Mientras trabajamos, como ya hemos comentado, **hicimos una version del programa que trabajaba con búsquedas dicotómicas y el resultado de la experiencia fue darnos cuenta de cuanta importancia podía llegar a tener el mantener la lista ordenada** para evitar usar búsquedas lineales y que el tiempo de ejecución se volviera a disparar.

**Tras analizar el fichero y destacar un patrón que pudiera servirnos** para, basandonos en el metodo split (de la clase String), separar las lineas del documento en información que nos fuera mas sencilla de manejar; **nos centramos en optimizar al máximo el funcionamiento de esta carga**.
Para realizar la operacion de una forma mas transparente al usuario y sin saturar la ventana de la consola,** hemos desarrollado un metodo que calcula el procentaje actual del documento y la imprime por pantalla en bloques de 10% en 10%** y sin repetirse ninguna de las impresiones.
Así mismo, **hemos implementado programación basada en multiples procesos para aligerar la carga del fichero con la opción de normalización de nombres que hemos decidido aportar**. Las diferencias las detallaremos ahora con mas datos.


